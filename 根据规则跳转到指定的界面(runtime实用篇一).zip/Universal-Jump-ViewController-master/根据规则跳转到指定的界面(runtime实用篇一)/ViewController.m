//
//  ViewController.m
//  根据规则跳转到指定的界面(runtime实用篇一)
//
//  Created by hans on 15/8/13.
//  Copyright (c) 2015年 hans. All rights reserved.
//

#import "ViewController.h"
#import <objc/runtime.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];


}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
