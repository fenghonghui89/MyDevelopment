//
//  ViewController.h
//  根据规则跳转到指定的界面(runtime实用篇一)
//
//  Created by hans on 15/8/13.
//  Copyright (c) 2015年 hans. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

