//
//  main.m
//  根据规则跳转到指定的界面(runtime实用篇一)
//
//  Created by hans on 15/8/13.
//  Copyright (c) 2015年 hans. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
