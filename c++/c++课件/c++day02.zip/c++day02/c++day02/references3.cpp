#include <iostream>
using namespace  std;
/* 函数返回值 只能作为右值 作为左值
   行为不确定 */
int   getmax(const int x,int y){
    return  x>y?x:y;
}
/* 返回引用类型 一般是要把 函数的返回值 
   作为左值 */
int&   getmaxref(int& x,int& y){
    return  x>y?x:y;
}
void   printInt(const int& val){
    cout<<val<<endl;
}
int&   getInt(){
    static int   data=1001;
    return  data;
}
int main(){
    int  x=100;
    int  y=20;
    //getmax(x,y)=1；
    getmaxref(x,y)=1;
    cout<<x<<endl;
    x=88;
    printInt(x);
    printInt(100);
    cout<<getInt()<<endl;
}

