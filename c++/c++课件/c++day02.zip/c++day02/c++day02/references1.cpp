#include <iostream>
using namespace  std;
int main(){
    int  var_i=100;
    int& rvar_i=var_i;
    cout<<rvar_i<<endl;
    var_i=10001;
    cout<<rvar_i<<endl;
    int& rrvar_i=rvar_i;
    var_i=10;
    cout<<rrvar_i<<endl;
    int   var_j=200;
    /* 这不是引用变量 只是赋值 */
    rvar_i=var_j;
    rvar_i=1234;
    cout<<var_j<<endl;
    const int& rc=100;
}

