#include <iostream>
using namespace  std;
int main(){
    int   i=100;
    int*  pi=&i;
    void* vp=pi;
    pi=static_cast<int*>(vp);
    volatile const  int  ci=99;
    int* pci=const_cast<int*>(&ci);
    *pci=19999;
    cout<<*pci<<endl;
    cout<<ci<<endl;
}