#include <iostream>
#include <cstdio>
using namespace std;

struct  Date{
    int  year;
    int  month;
    int  day;
    /* 设置日期 */
    void setDate(int y=2014,int m=1,
                 int d=1){
        year=y;
        month=m;
        day=d;
    }
    /* 显示日期 */
    void  showDate(){
        /*cout<<year<<"-"<<month<<"-"
        <<day<<endl;*/
        printf("%04d-%02d-%02d\n",
        year,month,day);
    }
};
int  main(){
    //Date  date();  函数声明
    Date    date;
    date.setDate();
    date.showDate();
    Date* date2=new Date;
    date2->setDate(2013,12,31);
    date2->showDate();
}

