#include <iostream>
using namespace std;

int main(){
    const int  i=99;
    //i=100;
    int   g=99;
    const int   *pg=&g;
    int   gg=88;
    //*pg=1000;
    /* 可以改变pg的指向 */
    pg=&gg;
    
    /* 引用和数组的 基本实现 */
    int  f=123;
    int* const rf=&f;
    int  ff=456;
    /* 不能改变rf的指向 */
    //rf=&ff;
    /*但是可以通过rf改变值*/
    *rf=ff;
}

