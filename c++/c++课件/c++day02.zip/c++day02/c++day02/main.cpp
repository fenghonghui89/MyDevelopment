//
//  main.cpp
//  c++day02
//
//  Created by Tarena on 13-12-31.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[])
{

    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

