#include <iostream>
using namespace  std;

void  myswap(int x,int y){
    int  temp=x;
    x=y;
    y=temp;
}
void  myswap(int* x,int* y){
    int  temp=*x;
    *x=*y;
    *y=temp;
}
void  cppswap(int& x,int& y){
    /*int   temp=x;
    x=y;
    y=temp;*/
    x=x^y;
    y=x^y;
    x=x^y;
}
int main(){
    int   x=100;
    int   y=99;
    /*int   temp=x;
    x=y;
    y=temp;*/
    //myswap(&x, &y);
    cppswap(x,y);
    cout<<"x="<<x<<","<<"y="<<y<<endl;
    
}


