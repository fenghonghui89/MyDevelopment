#include <iostream>
/* 第一个c++ 程序 */
int   main()
{
    std::cout<<"hello c++ app"<<std::endl;
    std::cout<<"this is first cpp \n";
    std::cout<<"hello"<<std::endl;
}