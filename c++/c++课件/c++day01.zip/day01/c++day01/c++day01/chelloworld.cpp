#include <cstdio>
/* 第一个使用c++ 写的c程序 */
int main()
{
    printf("hello c++ \n");
    printf("this is first cpp \n");
    printf("hello \n");
}