#include <iostream>
using namespace  std;
int   age=100;
namespace {
    void  show(){
        cout<<"this is noname namespace"<<endl;
    }
}
int main(){
    show();
    ::show();
    cout<<age<<endl;
    cout<<::age<<endl;
}