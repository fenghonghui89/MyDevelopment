#include <iostream>
using  namespace   std;
struct Emp{
    int  eno;
    char name[30];
    double salary;
    void  show(){
        cout<<eno<<":"<<name<<":"<<
        salary<<endl;
    }
};
/* typedef struct Emp  Emp; */
void  show(struct Emp  e){
    cout<<e.eno<<":"<<e.name<<":"<<
    e.salary<<endl;
}
int main(){
    Emp  var_emp={100,"xiaoqiang",1};
    show(var_emp);
    var_emp.show();
}

