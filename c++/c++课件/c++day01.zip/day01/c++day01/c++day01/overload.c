#include <stdio.h>
int    add(int  x,int  y){
    /* __Z3addii  _add */
    return  x+y;
}
/*  __Z3addid */
double add1(int x,double y){
    return  x+y;
}
double add2(double  x,double y){
    return  x+y;
}
int  main(){
    int  x=1;
    int  y=9526;
    add(x,y);
    double z=2.0;
    add(y,z);
}
