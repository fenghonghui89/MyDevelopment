#include <iostream>
using namespace std;
/* 第一个c++ 程序 */
int   main()
{
    cout<<"hello c++ app"<<endl;
    cout<<"this is first cpp \n";
    cout<<"hello"<<endl;
}