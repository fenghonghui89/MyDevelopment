#include <iostream>
using namespace std;
namespace IBM{
    int   age=50;
    void  show(){
        cout<<"this is ibm age is "<<age<<endl;
    }
}
namespace tarena{
    int   age=12;
    void  show();
}
namespace tarena {
    // extern int    age;
    void   show(){
        cout<<"this is tarena age is "<<age<<endl;
    }
}
int main()
{
    IBM::age=52;
    IBM::show();
    tarena::show();
    tarena::age++;
    tarena::show();
}

