%:include <iostream>
using namespace std;
int main()<%
    bool  flag;
    flag=false;
    flag="abc";
    if(flag){
        cout<<"flag is true "<<flag<<endl;
    %>
}