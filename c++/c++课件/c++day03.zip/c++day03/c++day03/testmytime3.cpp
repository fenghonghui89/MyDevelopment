#include "mytime3.h"

int main(){
    MyTime   mt;
    mt.run();
}