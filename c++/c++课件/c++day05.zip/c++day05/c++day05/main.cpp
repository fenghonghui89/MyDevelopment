//
//  main.cpp
//  c++day05
//
//  Created by Tarena on 14-1-4.
//  Copyright (c) 2014年 Tarena. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[])
{

    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

