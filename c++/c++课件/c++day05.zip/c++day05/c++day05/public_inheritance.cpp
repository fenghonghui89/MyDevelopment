#include <iostream>
using namespace  std;
class  A{
public:
    void   showPublic(){
        cout<<"showPublic()"<<endl;
    }
protected:
    void   showProtected(){
        cout<<"showProtected()"<<endl;
    }
private:
    void   showPrivate(){
        cout<<"showPrivate()"<<endl;
    }
};
class  B:public A{
public:
    void  testfun(){
        showProtected();
       // showPrivate();
    }
};
int main(){
    B   b;
    b.showPublic();
    b.testfun();
    //b.showProtected();
    //b.showPrivate();
}



