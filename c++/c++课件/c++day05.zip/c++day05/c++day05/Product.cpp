#include <iostream>
using namespace std;
class  Product{
    double   price;
    int      count;
public:
    Product(double price,int count):
    price(price),count(count){
    }
    double  getPrice(){
        return  price*count;
    }
    double  operator()(double p,int c){
        return  p*c;
    }
};
double   showSumPrice(double price,
       int  count,Product p){
    return  p(price,count);
}
int main(){
    Product   app(1.2,12);
    cout<<app.getPrice()<<endl;
    cout<<app(1.0,12)<<endl;
    cout<<showSumPrice(1.1,11,app)<<endl;
}
