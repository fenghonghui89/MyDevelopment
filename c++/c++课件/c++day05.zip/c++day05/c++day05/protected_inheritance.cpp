#include <iostream>
using namespace  std;
class  A{
public:
    void   showPublic(){
        cout<<"showPublic()"<<endl;
    }
protected:
    void   showProtected(){
        cout<<"showProtected()"<<endl;
    }
private:
    void   showPrivate(){
        cout<<"showPrivate()"<<endl;
    }
};
class  B:protected A{
public:
    void  testfun(){
        showPublic();
        showProtected();
        //showPrivate();
    }
};
int main(){
    B   b;
    b.testfun();
    //b.showPublic();
}


