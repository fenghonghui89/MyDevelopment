#include <iostream>
using namespace  std;
class  A{
public:
    void   showPublic(){
        cout<<"showPublic()"<<endl;
    }
protected:
    void   showProtected(){
        cout<<"showProtected()"<<endl;
    }
private:
    void   showPrivate(){
        cout<<"showPrivate()"<<endl;
    }
/* 公开A类的私有数据 */
public:
    void   publicPrivate(){
        showPrivate();
    }
};
class  B:private A{
/* 公开B类的私有数据 */
public:
    void  testfun(){
        showPublic();
        showProtected();
        publicPrivate();
    }
};
int main(){
    B  b;
    b.testfun();
    //b.showPublic();
}




