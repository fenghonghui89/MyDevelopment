#include <iostream>
#include <sstream>
using namespace  std;
class Fraction{
    int   x;
    int   y;
public:
    Fraction(int x=0,int y=1):x(x),y(y){
    }
    /* 需要把Fraction 类型转换成double*/
    operator double (){
        return  x/(y*1.0);
    }
    operator string(){
        /*char  datastr[30];
        sprintf(datastr,"%d/%d",x,y);
        return datastr;*/
        stringstream datastr;
        datastr<<x;
        datastr<<"/";
        datastr<<y;
        return datastr.str();
    }
};
int main(){
    
    Fraction   f(1,5);
    double   d=(double)f;
    cout<<d<<endl;
    int    di=(int)f;
    cout<<di<<endl;
    string ds=(string)f;
    cout<<ds<<endl;
}
