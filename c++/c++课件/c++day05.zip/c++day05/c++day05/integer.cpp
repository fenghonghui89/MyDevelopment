#include <iostream>
using  namespace  std;
class  Integer{
    int  val;
public:
    Integer(int val=0):val(val){
    }
    bool  operator==(const Integer& b){
        return  this->val==b.val;
    }
    /* 两个整数相减 a-b */
    Integer  operator-(int b){
        return  val-b;
    }
    /* 支持输出 */
    friend  ostream&   operator<<(ostream& os,const Integer& i);
    friend Integer&   operator--(Integer& i);
    friend Integer   operator--(Integer& i,int);
};
/* 使用全局函数 实现前减减 --a 
Integer&   operator--()
Integer&   operator--(Integer& i)*/
Integer&   operator--(Integer& i){
    --i.val;
    return  i;
}
Integer   operator--(Integer& i,int){
    return  Integer(i.val--);
}
ostream&   operator<<(ostream& os,const Integer& i){
    cout<<i.val;
    return  os;
}
int  main(){
    Integer   a(100);
    Integer   b=200;
    --b;
    b--;
    cout<<b<<endl;
    /* 赋值运算符 默认做的和拷贝构造函数
       完全一样 */
    a=b;
    cout<<a<<endl;
    cout<<b-5<<endl;
    if(a==b){
        cout<<"a is equal b"<<endl;
    }
    if(a.operator==(b)){
        cout<<"a is equal b"<<endl;
    }
}
