#include <iostream>
using namespace std;
class  A{
public:
    A(){
        cout<<"A()"<<endl;
    }
    ~A(){
        cout<<"~A()"<<endl;
    }
    void   show(){
        cout<<"this is A show"<<endl;
    }
};
typedef A  T;
class   myautoptr{
    T*   ptr;
public:
    myautoptr(T *ptr):ptr(ptr){
    
    }
    ~myautoptr(){
        delete  ptr;
    }
    T*  operator->(){
        return  ptr;
    }
    T&   operator*(){
        return *ptr;
    }
};
#include <memory>
int main(){
    A *a=new A();
    auto_ptr<T>  myptr(a);
    myptr->show();
    /*myautoptr  myptr(a);
    myptr->show();
    //myptr.operator->()->show();
    (*myptr).show();*/
}

