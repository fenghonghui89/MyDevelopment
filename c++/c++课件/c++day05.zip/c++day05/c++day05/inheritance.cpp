#include <iostream>
using namespace std;
class  Animal{
public:
    void  run(){
        cout<<"this is animal run"<<endl;
    }
};
class  Dog/*:public Animal*/{
private:
    Animal  a;
public:
    void  run(){
        a.run();
    }
};
/* 让Cat 继承 Animal 
   并且扩展 Animal 的功能 
   void  catFun(){ } */
class  Cat:public Animal{
public:
    void  catFun(){
        cout<<"抓老鼠"<<endl;
    }
};
int main(){
    Dog    dog;
    dog.run();
    Cat    cat;
    cat.run();
    cat.catFun();
}
