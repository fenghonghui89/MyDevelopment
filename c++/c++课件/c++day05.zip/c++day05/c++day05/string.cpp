#include <iostream>
#include <string>
using namespace std;
int main(){
    string  a;
    string  b("hello");
    a=b;
    if(a==b){
        cout<<"a is equal b"<<endl;
    }
    string  c("hello");
    if(a==c ){
        cout<<"a is equal c"<<endl;
    }
    cout<<c<<endl;
    c=c+" world";
    c+=" hello";
    cout<<c<<endl;
    c="one world one dream";
    /* c++ string 转换成 c的字符串 */
    const char*  cstr=c.c_str();
    cout<<cstr<<endl;
    cout<<c.at(0)<<endl;
    cout<<c[0]<<endl;
    try{
    cout<<c.at(10)<<endl;
    cout<<c[10]<<endl;
    }catch(...){
        cout<<"访问出错 检查下标"<<endl;
    }
    cout<<c.length()<<endl;
}
