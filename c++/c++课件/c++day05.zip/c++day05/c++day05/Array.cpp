#include <iostream>
using namespace std;
typedef  int   T;
class Array{
    T*  data;//真正存储数据的地方
    int size;//运算个数
    int capacity;//动态容量
    /* 扩容函数 */
    void  expend(){
        capacity=capacity*2+1;
        T*  temp=new T[capacity];
        /* 复制原来的数据 */
        for(int i=0;i<size;i++){
            temp[i]=data[i];
        }
        delete[]  data;
        data=temp;
    }
public:
    explicit  Array(int capacity=5):size(0),
    capacity(capacity){
        data=new T[capacity];
    }
    void   push_back(T d){
        if(size==capacity){
           //扩容
            expend();
        }
        data[size++]=d;
    }
public:
    T operator[](int ind){
        if(ind>=size){
            throw "out of range";
        }
        return  data[ind];
    }
    /* 想一下赋值运算符的实现 */
    Array&   operator=(const Array& a){
        /* 防止自己赋值给自己 */
        if(this==&a){
            return *this;
        }
        size=a.size;
        capacity=a.capacity;
        /* 处理堆内存 */
        delete[] data;
        data=new T[capacity];
        /* 复制a中的数据 */
        for(int i=0;i<size;i++){
            data[i]=a.data[i];
        }
        return *this;
    }
    /* 析构函数  和 拷贝构造函数完成 */
    ~Array(){
        delete[]  data;
    }
    Array(const Array& arr){
        delete[]   data;
        size=arr.size;
        capacity=arr.capacity;
        data=new T[capacity];
        for(int i=0;i<size;i++){
            data[i]=arr.data[i];
        }
    }
};
int  main(){
    //Array   arr=999;
    Array   arr(999);
    arr.push_back(100);
    arr.push_back(200);
    Array   arr2;
    arr2.push_back(123);
    arr2.push_back(456);
    arr2.push_back(789);
    arr=arr2;
    /* T operator[](int ind)*/
    try{
    cout<<arr[0]<<endl;
    cout<<arr[1]<<endl;
    cout<<arr[2]<<endl;
    cout<<arr[11112]<<endl;
    }catch(const char* e){
        cout<<e<<endl;
    }
}
