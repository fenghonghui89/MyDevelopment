#include <iostream>
using namespace std;
class Integer{
    int   val;
public:
    Integer(int val=0):val(val){
    }
    Integer  operator!(){
        return  Integer(!val);
    }
    Integer  operator-(){
        return  Integer(-val);
    }
    Integer&  operator++(){
        val++;
        return *this;
    }
    Integer  operator++(int){
        return Integer(val++);
    }
    /*Integer  operator+(const Integer& b){
        return  Integer(val+b.val);
    }*/
    friend Integer  operator+(Integer a,Integer b);
    friend ostream&   operator<<(ostream& os,const Integer& i);
    friend istream&   operator>>(istream& is,Integer& i){
        return  is>>i.val;
    }
};
Integer   operator+(Integer a,Integer b){
    return  Integer(a.val+b.val);
}
ostream&   operator<<(ostream& os,const Integer& i){
    return os<<i.val;
}

int main(){
    Integer    var_i(99);
    //++++var_i;
    cout<<var_i++<<endl;
    cout<<var_i<<endl;
    
    Integer    x=100;
    Integer    temp=-(!x);
    Integer    temp2=!temp;
    cout<<temp2<<endl;
    cout<<x<<endl;
    
    Integer  a(1);
    Integer  b(9526);
    /* operator+(const Integer&  b)*/
    Integer  c=a+b;
    /* cout  ostream  c Integer
       ostream   operator<<(Integer c)
       operator<<(ostream& os,Integer c);
    */
    cout<<(a+b)<<endl;
    /* cin   X   a  Integer
       X       operator>>(Integer a)
       operator>>(istream& is,Integer& a)*/
    cin>>a;
    cout<<a<<endl;
}

