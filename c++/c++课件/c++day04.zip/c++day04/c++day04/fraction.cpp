#include <iostream>
using namespace std;
class  Fraction{
public:
    int  x;
    int  y;
public:
    Fraction(int x=0,int y=1):x(x),y(y){
      
    }
    void   show(){
        cout<<x<<"/"<<y<<endl;
    }
    Fraction  operator*(const Fraction& f2){
        cout<<"mem operator*"<<endl;
        return  Fraction(x*f2.x,y*f2.y);
    }
    /*Fraction f1.add(f2) 
      f1+f2
    Fraction   operator+(Fraction  f2){
        Fraction  temp;
        temp.x=x*f2.y+y*f2.x;
        temp.y=y*f2.y;
        return temp;
    }*/
    /* 写一个成员形式的 *= */
    void   operator*=(Fraction f2){
        x*=f2.x;
        y*=f2.y;
    }
};
/* 设计一个全局函数 表达两个分数相加 */
Fraction operator+(const Fraction& f1,const Fraction& f2){
    Fraction  temp;
    temp.x=f1.x*f2.y+f1.y*f2.x;
    temp.y=f1.y*f2.y;
    return temp;
}
/* 设计一个全局函数 表达两个分数相乘 */
Fraction  operator*(const Fraction& f1,const Fraction& f2){
    cout<<"g operator*"<<endl;
return  Fraction(f1.x*f2.x,f1.y*f2.y);
}
/*
void  operator*=(Fraction& f1,const Fraction& f2){
    cout<<"g operator*="<<endl;
    f1.x=f1.x*f2.x;
    f1.y=f1.y*f2.y;
}*/
int main(){
    Fraction  f1(1,2);
    Fraction  f2(1,3);
    f1*=f2;
    f1.show();
    Fraction ff3=f1*f2;
    ff3.show();
    //Fraction  f3=f1.add(f2);
    Fraction    f3=f1+f2;
    f3.show();
    Fraction ff=operator+(f1,f2);
    ff.show();
}