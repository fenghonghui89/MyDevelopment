#include <iostream>
using namespace std;
struct   Date{
    int  year;
    int  month;
    int  day;
public:
    Date(int year=2014,int month=1,int day=3){
        this->year=year;
        this->month=month;
        this->day=day;
    }
    int   getYear(){
        return  year;
    }
    int   getMonth(){
        return  month;
    }
};
int   main(){
    /* 指向成员函数的指针 */
    int   (Date::*pfun)();
    pfun=&Date::getYear;
    Date   testdate;
    int year=(testdate.*pfun)();
    cout<<"year="<<year<<endl;
    /* 定义一个成员函数指针 指向getMonth 
       得到month 对应的值 */
    int   (Date::*pfun2)();
    pfun2=&Date::getMonth;
    cout<<(testdate.*pfun2)()<<endl;
    
    
    
    /* 定义一个成员指针 指向成员year */
    union {
    int  Date::*mptr;
    int  *pi;
    };
    /* 给mptr 赋值 */
    mptr=&Date::year;
    /* 创建对象 */
    Date   *date=new Date;
    /* 得到成员指针对应的成员变量的值 */
    cout<<date->*mptr<<endl;
    /* 把指针指向 month 这个成员变量 输出
       这个指针对应的成员的值 */
    mptr=&Date::month;
    cout<<date->*mptr<<endl;
    /* 成员指针的本质 相对地址偏移量 */
    cout<<"mptr="<<mptr<<endl;
    cout<<"pi="<<pi<<endl;
    int *mypi=(int*)date;
    cout<<*mypi<<endl;
    cout<<*(mypi+1)<<endl;
    cout<<*(mypi+2)<<endl;
}

