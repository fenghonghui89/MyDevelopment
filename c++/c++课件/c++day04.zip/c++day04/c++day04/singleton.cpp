#include <iostream>
using namespace std;
class   Director{
private:
    Director(){}
    Director(const Director& d){}
    static  Director  dire;
public:
    static Director&   getInstance(){
        return  dire;
    }
};
Director   Director::dire;
int  main(){
    Director& d1=Director::getInstance();
    Director& d2=Director::getInstance();
    cout<<&d1<<endl;
    cout<<&d2<<endl;
}



