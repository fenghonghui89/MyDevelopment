//
//  XARightTransition.h
//  XANavBarTransitionDemo
//
//  Created by xangam on 2018/5/23.
//  Copyright © 2018年 Lan. All rights reserved.
//

#import "XABaseTransition.h"

@interface XARightTransition : XABaseTransition

@end
