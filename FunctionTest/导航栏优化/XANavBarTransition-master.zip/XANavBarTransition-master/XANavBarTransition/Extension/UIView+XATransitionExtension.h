//
//  UIView+XATransitionExtension.h
//  YXXiaoKaXiuSDK
//
//  Created by xangam on 2018/7/24.
//  Copyright © 2018年 Lan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (XATransitionExtension)
- (BOOL)xa_isDisplaying;
@end
