//
//  XARightTransitionAnimation.h
//
//
//  Created by XangAm on 2017/9/3.
//  Copyright © 2017年 Lan. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "XABaseTransitionAnimation.h"
@interface XARightTransitionAnimation : XABaseTransitionAnimation


@end
