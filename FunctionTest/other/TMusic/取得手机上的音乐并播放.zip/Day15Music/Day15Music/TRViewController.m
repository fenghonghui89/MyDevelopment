//
//  TRViewController.m
//  Day15Music
//
//  Created by Tarena on 13-12-20.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()

@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
//    复习Bundle
//    //只能取到bundle根目录下面的图片
//	NSString *imagePath = [[NSBundle mainBundle]pathForResource:@"yangmi01" ofType:@"jpg"];
//    NSData *data = [NSData dataWithContentsOfFile:imagePath];
//    NSLog(@"%d",data.length);
//    NSLog(@"%@",imagePath);
//    
//    UIImage *image = [UIImage imageNamed:@"杨幂/yangmi01.jpg"];
//    NSLog(@"width = %f",image.size.width);
//    NSString *mainPath = [[NSBundle mainBundle]resourcePath];
//    mainPath = [mainPath stringByAppendingPathComponent:@"杨幂"];
//    NSArray *fileNames = [[NSFileManager defaultManager]contentsOfDirectoryAtPath:mainPath error:nil];
//    NSMutableArray *imagePaths = [NSMutableArray array];
//    for (NSString *fileName in fileNames) {
//        if ([fileName hasSuffix:@"jpg"]) {
//            NSString *imagePath = [mainPath stringByAppendingPathComponent:fileName];
//            [imagePaths addObject:imagePath];
//        }
//    }
//    NSLog(@"%@",imagePaths);
    
    
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
