//
//  UMSocialThumblrHandler.h
//  SocialSDK
//
//  Created by Gavin Ye on 8/20/14.
//  Copyright (c) 2014 Umeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UMSocialTumblrHandler : NSObject

+(void)openTumblr;
@end
