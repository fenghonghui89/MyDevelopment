//
//  UMSocialTabViewController.h
//  SocialSDK
//
//  Created by yeahugo on 13-1-25.
//  Copyright (c) 2013年 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UMSocialTabBarController : UITabBarController

@end
