//
//  TRViewController.m
//  Day11SaxXML
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"
#import "TRBook.h"
@interface TRViewController ()
@property (nonatomic, strong)TRBook *currentBook;
@property (nonatomic, copy)NSString *currentString;
@property (nonatomic, strong)NSMutableArray *books;
@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.books = [NSMutableArray array];
    NSString *xmlPath = [[NSBundle mainBundle]pathForResource:@"books" ofType:@"xml"];
    NSData *xmlData = [NSData dataWithContentsOfFile:xmlPath];
    //创建解析器对象
    NSXMLParser *parser = [[NSXMLParser alloc]initWithData:xmlData];

    parser.delegate = self;
    //开始解析
    [parser parse];
    
    
    for (TRBook *book in self.books) {
        NSLog(@"名称：%@ 作者：%@ 页数：%@ 价格：%@",book.name,book.author,book.page,book.price);
    }
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    NSLog(@"didStartElement   %@",elementName);
    if ([elementName isEqualToString:@"book"]) {
       self.currentBook = [[TRBook alloc]init];
        [self.books addObject:self.currentBook];
    }
    
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    NSLog(@"foundCharacters   %@",string);
    self.currentString = string;
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    NSLog(@"didEndElement     %@",elementName);
    
    if ([elementName isEqualToString:@"name"]) {
        self.currentBook.name = self.currentString;
    }else if ([elementName isEqualToString:@"author"]) {
        self.currentBook.author = self.currentString;
    }else if ([elementName isEqualToString:@"price"]) {
        self.currentBook.price = self.currentString;
    }else if ([elementName isEqualToString:@"page"]) {
        self.currentBook.page = self.currentString;
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
