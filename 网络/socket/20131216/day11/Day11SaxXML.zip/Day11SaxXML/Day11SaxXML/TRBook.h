//
//  TRBook.h
//  Day11SaxXML
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRBook : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *author;
@property (nonatomic, strong) NSString *price;
@property (nonatomic, strong) NSString *page;

@end
