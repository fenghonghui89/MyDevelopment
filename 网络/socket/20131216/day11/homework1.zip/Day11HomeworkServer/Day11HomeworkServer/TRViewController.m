//
//  TRViewController.m
//  Day11HomeworkServer
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()
@property (nonatomic ,strong)AsyncSocket *serverSocket;
@property (nonatomic ,strong)AsyncSocket *myNewSocket;
@property (weak, nonatomic) IBOutlet UIProgressView *myPV;
@property (nonatomic, copy)NSString *host;
@property (nonatomic, copy)NSString *fileName;
@property (nonatomic)int fileLength;
@property (nonatomic, strong)NSMutableData *fileData;
@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	self.serverSocket = [[AsyncSocket alloc]initWithDelegate:self];
    [self.serverSocket acceptOnPort:8000 error:Nil];
    
    
}

-(void)onSocket:(AsyncSocket *)sock didAcceptNewSocket:(AsyncSocket *)newSocket{
    self.myNewSocket = newSocket;
  
}

-(void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port{
    self.host = host;
    [self.myNewSocket readDataWithTimeout:-1 tag:0];
}
-(void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
//    320
//    300
//    20
    if (data.length>100) {
    NSData *headerData = [data subdataWithRange:NSMakeRange(0, 100)];
    NSString *headerString = [[NSString alloc]initWithData:headerData encoding:NSUTF8StringEncoding];
    if (headerString && [headerString componentsSeparatedByString:@"&&"].count == 3) {//条件满足说明为第一次数据 里面有消息头
        NSArray *headers = [headerString componentsSeparatedByString:@"&&"];
        NSString *type = headers[0];
        if ([type isEqualToString:@"upload"]) {
            
            self.fileName = headers[1];
            self.fileLength = [headers[2]intValue];
            NSData *subFileData = [data subdataWithRange:NSMakeRange(100, data.length-100)];
            self.fileData = [NSMutableData data];
            
            [self.fileData appendData:subFileData];

            if (self.fileData.length == self.fileLength) {
                NSString *newFilePath = [@"/Users/apple/Desktop/serverFile" stringByAppendingPathComponent:self.fileName];
                [self.fileData writeToFile:newFilePath atomically:YES];
            }
        }
        
    }else{//如果不是第一部分数据 没有消息头的情况
        [self.fileData appendData:data];
        //判断是否下载完成
        if (self.fileData.length == self.fileLength) {
            NSString *newFilePath = [@"/Users/apple/Desktop/serverFile" stringByAppendingPathComponent:self.fileName];
            [self.fileData writeToFile:newFilePath atomically:YES];
        }
        
        
    }
        
        
        
    }else{//如果接收到的数据长度不足100 那能肯定此次数据为文件的数据 直接保存
        [self.fileData appendData:data];
        //判断是否下载完成
        if (self.fileData.length == self.fileLength) {
            NSString *newFilePath = [@"/Users/apple/Desktop/serverFile" stringByAppendingPathComponent:self.fileName];
            [self.fileData writeToFile:newFilePath atomically:YES];
        }
    }
    self.myPV.progress = self.fileData.length*1.0/self.fileLength;
    
    //继续读取数据
    [sock readDataWithTimeout:-1 tag:0];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
