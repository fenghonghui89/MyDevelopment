//
//  TRLocalFileListViewController.m
//  Day11Homework
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRLocalFileListViewController.h"

@interface TRLocalFileListViewController ()
@property (nonatomic, strong)NSMutableArray *files;
@property (nonatomic, strong)AsyncSocket *clientSocket;
@end

@implementation TRLocalFileListViewController



- (void)viewDidLoad
{
    [super viewDidLoad];

    self.files = [TRUtils getAllLocalFileInDirectoryPath:@"/Users/apple/Desktop/localFile"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return self.files.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    TRFile *file = self.files[indexPath.row];
    cell.textLabel.text = file.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d kb",file.length/1024];
    
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    TRFile *file = self.files[indexPath.row];
    //拼接消息头
    NSString *header = [NSString stringWithFormat:@"upload&&%@&&%d",file.name,file.length];
    NSMutableData *allData = [TRUtils getAllDataByHeader:header];
    NSData *fileData = [NSData dataWithContentsOfFile:file.path];
    
    [allData appendData:fileData];
    
    self.clientSocket = [[AsyncSocket alloc]initWithDelegate:self];
    
    [self.clientSocket connectToHost:@"192.168.2.3" onPort:8000 error:Nil];
    [self.clientSocket writeData:allData withTimeout:-1 tag:0];

}

-(void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag{

    UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"文件发送成功！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:Nil, nil];
    [av show];
    
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a story board-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

 */

@end
