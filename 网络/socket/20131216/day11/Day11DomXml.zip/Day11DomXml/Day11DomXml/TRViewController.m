//
//  TRViewController.m
//  Day11DomXml
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"
#import "TBXML.h"
@interface TRViewController ()

@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    TBXML *xml = [[TBXML alloc]initWithXMLData:[NSData dataWithContentsOfFile:@"/Users/apple/Desktop/Day11DomXml/Day11DomXml/books.xml"] error:Nil];
    TBXMLElement *rootElement = xml.rootXMLElement;
    
    if (rootElement) {
        TBXMLElement *bookElement = [TBXML childElementNamed:@"book" parentElement:rootElement];
        
        while (bookElement) {
            
            
            NSString *bookId = [TBXML valueOfAttributeNamed:@"id" forElement:bookElement];
            
            
            TBXMLElement *nameEle = [TBXML childElementNamed:@"name" parentElement:bookElement];
            TBXMLElement *authorEle = [TBXML childElementNamed:@"author" parentElement:bookElement];
            TBXMLElement *pageEle = [TBXML childElementNamed:@"page" parentElement:bookElement];
            TBXMLElement *priceEle = [TBXML childElementNamed:@"price" parentElement:bookElement];
            
            NSString *name = [TBXML textForElement:nameEle];
             NSString *author = [TBXML textForElement:authorEle];
             NSString *page = [TBXML textForElement:pageEle];
             NSString *price = [TBXML textForElement:priceEle];
            NSLog(@"id = %@ %@ %@ %@ %@",bookId,name,author,page,price);
            
            
            
            
            
            bookElement = [TBXML nextSiblingNamed:@"book" searchFromElement:bookElement];
        }
        
        
        
    }
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
