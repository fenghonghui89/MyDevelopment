//
//  TRFile.m
//  Day11Homework
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRFile.h"

@implementation TRFile
- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:_name forKey:@"name"];
    [aCoder encodeObject:_path forKey:@"path"];
    [aCoder encodeInteger:_length forKey:@"length"];
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
           self.path = [aDecoder decodeObjectForKey:@"path"];
           self.length = [aDecoder decodeIntegerForKey:@"length"];
    }
    return self;
}
@end
