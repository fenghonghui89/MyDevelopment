//
//  TRFile.h
//  Day11Homework
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRFile : NSObject<NSCoding>
@property (nonatomic, copy)NSString *name;
@property (nonatomic)int length;
@property (nonatomic, copy)NSString *path;
@end
