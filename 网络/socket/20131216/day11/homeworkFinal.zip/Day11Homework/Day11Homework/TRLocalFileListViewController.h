//
//  TRLocalFileListViewController.h
//  Day11Homework
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRFile.h"
#import "TRUtils.h"
#import "AsyncSocket.h"
@interface TRLocalFileListViewController : UITableViewController<AsyncSocketDelegate>

@end
