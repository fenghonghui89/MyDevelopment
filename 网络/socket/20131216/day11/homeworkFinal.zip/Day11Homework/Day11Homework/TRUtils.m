//
//  TRUtils.m
//  Day11Homework
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRUtils.h"
#import "TRFile.h"
@implementation TRUtils
+(NSMutableArray *)getAllLocalFileInDirectoryPath:(NSString *)path{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *fileNames = [fm contentsOfDirectoryAtPath:path error:nil];
    NSMutableArray *files = [NSMutableArray array];
    for (NSString *fileName in fileNames) {
        NSString *filePath = [path stringByAppendingPathComponent:fileName];
        
        TRFile *file = [[TRFile alloc]init];
        file.name = fileName;
        file.path = filePath;
        NSFileHandle *reader = [NSFileHandle fileHandleForReadingAtPath:filePath];
        
        //仅仅把游标移动到文件最后并且得到了文件的总长度 并没有把文件加载到内存中
        file.length = [reader seekToEndOfFile];
        
        
        [files addObject:file];
        
    }
    
    
    return files;
}

+(NSMutableData *)getAllDataByHeader:(NSString *)header{
    NSData *headerData = [header dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableData *allData = [NSMutableData dataWithLength:100];
    [allData replaceBytesInRange:NSMakeRange(0, headerData.length) withBytes:headerData.bytes];
    
    return allData;
}
@end
