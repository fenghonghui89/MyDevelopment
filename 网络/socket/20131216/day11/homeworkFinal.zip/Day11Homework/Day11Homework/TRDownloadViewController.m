//
//  TRDownloadViewController.m
//  Day11Homework
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRDownloadViewController.h"
#import "TRUtils.h"
@interface TRDownloadViewController ()
@property (weak, nonatomic) IBOutlet UIProgressView *myPV;
@property (nonatomic, strong)AsyncSocket *clientSocket;
@property (nonatomic, strong)NSMutableData *fileData;
@end

@implementation TRDownloadViewController



- (void)viewDidLoad
{
    [super viewDidLoad];
	self.fileData = [NSMutableData data];
    self.clientSocket = [[AsyncSocket alloc]initWithDelegate:self];
    [self.clientSocket connectToHost:@"192.168.2.3" onPort:8000 error:Nil];
    
    NSString *header = [NSString stringWithFormat:@"download&&%@&&",self.downloadFile.path];
    
    NSMutableData *allData = [TRUtils getAllDataByHeader:header];
    [self.clientSocket writeData:allData withTimeout:-1 tag:0];
    
    [self.clientSocket readDataWithTimeout:-1 tag:0];
    
    
    
    
}
-(void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    
    [self.fileData appendData:data];
    if (self.fileData.length == self.downloadFile.length) {
        NSString *newPath = [@"/Users/apple/Desktop/localFile" stringByAppendingPathComponent:self.downloadFile.name];
        [self.fileData writeToFile:newPath atomically:YES];
        
        UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:[NSString stringWithFormat:@"文件%@接收成功！",self.downloadFile.name] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:Nil, nil];
        [av show];
    }
    [sock readDataWithTimeout:-1 tag:0];
    
    self.myPV.progress = self.fileData.length*1.0/self.downloadFile.length;
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
