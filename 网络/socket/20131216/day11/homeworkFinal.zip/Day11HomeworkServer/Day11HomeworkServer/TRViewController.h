//
//  TRViewController.h
//  Day11HomeworkServer
//
//  Created by Tarena on 13-12-16.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncSocket.h"
@interface TRViewController : UIViewController<AsyncSocketDelegate>
@property (weak, nonatomic) IBOutlet UILabel *myStutasLable;

@end
