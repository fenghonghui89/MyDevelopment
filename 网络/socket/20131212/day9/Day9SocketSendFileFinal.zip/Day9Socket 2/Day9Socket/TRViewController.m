//
//  TRViewController.m
//  Day9Socket
//
//  Created by Tarena on 13-12-12.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()
@property (nonatomic, strong)AsyncSocket *serverSocket;
@property (nonatomic, strong)AsyncSocket *myNewSocket;
@property (nonatomic, strong)AsyncSocket *clientSocket;
@property (nonatomic, strong)NSMutableData *fileAllData;
@property (nonatomic) int reciveFileLength;
@property (nonatomic, copy) NSString *reciveFileName;
@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //创建服务器
    self.serverSocket = [[AsyncSocket alloc]initWithDelegate:self];
    [self.serverSocket acceptOnPort:8000 error:nil];
   
}
//当连接成功的时候调用 只要用于获取对方的ip
-(void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port{
    NSLog(@"对方的ip地址为：%@",host);
}
//当有客户端请求连接的时候会进到此方法
-(void)onSocket:(AsyncSocket *)sock didAcceptNewSocket:(AsyncSocket *)newSocket{
    
    //需要把newSocket记住 不然newSocket就会被释放掉
    self.myNewSocket = newSocket;
    //有人进来了  就调用接收数据的方法
    [newSocket readDataWithTimeout:-1 tag:0];
}
//读到数据的时候会进到此方法
-(void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    NSData *headerData = [data subdataWithRange:NSMakeRange(0, 100)];
    NSString *headerString = [[NSString alloc]initWithData:headerData encoding:NSUTF8StringEncoding];//如果不是第一次的数据大部分为nil 也有个别情况会是乱码

    if (headerString && [headerString componentsSeparatedByString:@"&&"].count == 2) {//两个条件都满足 说明是第一部分数据
        
        NSArray *headers = [headerString componentsSeparatedByString:@"&&"];
        NSString *fileName = [headers objectAtIndex:0];
        int fileLength = [headers[1] intValue];
        self.reciveFileLength = fileLength;
        self.reciveFileName = fileName;
        
        NSData *subFileData = [data subdataWithRange:NSMakeRange(100, data.length-100)];
        
         self.fileAllData = [NSMutableData data];
        [self.fileAllData appendData:subFileData];
        //判断文件是否接受完成
        if (self.fileAllData.length == self.reciveFileLength) {
            NSString *newPath = [@"/Users/apple/Pictures/reciveFile" stringByAppendingPathComponent:self.reciveFileName];
            [self.fileAllData writeToFile:newPath atomically:YES];
        }
        
    }else{//如果接收到的不是第一次的数据 直接把接收到的数据加到fileAllData里面
        [self.fileAllData appendData:data];
        
        if (self.fileAllData.length == self.reciveFileLength) {
            NSString *newPath = [@"/Users/apple/Pictures/reciveFile" stringByAppendingPathComponent:self.reciveFileName];
            [self.fileAllData writeToFile:newPath atomically:YES];
        }
        
    }
    
    //继续读取后面的数据
    [sock readDataWithTimeout:-1 tag:0];
}









//客户端代码
- (IBAction)clicked:(id)sender {
    //    1.创建Socket对象
    self.clientSocket = [[AsyncSocket alloc]initWithDelegate:self];
    //2.请求建立连接
    [_clientSocket connectToHost:@"127.0.0.1"onPort:8000 error:nil];
    NSString *filePath = @"/Users/apple/Desktop/罗志祥：走好人生的下坡路.mp4";
    NSData *fileData = [NSData dataWithContentsOfFile:filePath];
    
    NSString *fileName = [filePath lastPathComponent];
    int fileLength = fileData.length;
    NSString *headerString = [NSString stringWithFormat:@"%@&&%d",fileName,fileLength];
    NSData *headerData = [headerString dataUsingEncoding:NSUTF8StringEncoding];
    //创建一个长度为100个字节的可变长度data
     NSMutableData *sendAllData = [NSMutableData dataWithLength:100];
//    headerData.bytes 是c语言里面表示二进制数据的类型
    [sendAllData replaceBytesInRange:NSMakeRange(0, headerData.length) withBytes:headerData.bytes];
    
    [sendAllData appendData:fileData];
    
    [self.clientSocket writeData:sendAllData withTimeout:-1 tag:0];
    
 
   
}
-(void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag{
    NSLog(@"发送成功了！");
}


//010101001010100000000000000010101010100101010100101010100101010101010010101010100101010100101010101001010101001010101010


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
