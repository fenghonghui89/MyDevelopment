//
//  TRViewController.m
//  Day9SocketClient
//
//  Created by Tarena on 13-12-12.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()

@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
 
}
- (IBAction)clicked:(id)sender {
//    1.创建Socket对象
    AsyncSocket *clientSocket = [[AsyncSocket alloc]initWithDelegate:self];
    //2.请求建立连接
    [clientSocket connectToHost:@"服务器的ip 想着改了" onPort:8000 error:nil];
    NSString *str = @"你好！！吃了没！";
    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
    [clientSocket writeData:data withTimeout:-1 tag:0];
    
//    [clientSocket disconnect]; 断开连接
}
-(void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag{
    NSLog(@"发送成功了！");
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
