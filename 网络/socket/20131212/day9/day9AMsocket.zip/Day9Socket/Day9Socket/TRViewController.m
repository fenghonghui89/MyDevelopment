//
//  TRViewController.m
//  Day9Socket
//
//  Created by Tarena on 13-12-12.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()
@property (nonatomic, strong)AsyncSocket *serverSocket;
@property (nonatomic, strong)AsyncSocket *myNewSocket;
@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //创建服务器
    self.serverSocket = [[AsyncSocket alloc]initWithDelegate:self];
    NSError *err = nil;
    [self.serverSocket acceptOnPort:8000 error:&err];
    if (err) {
        NSLog(@"%@",[err localizedDescription]);
    }
}
//当连接成功的时候调用 只要用于获取对方的ip
-(void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port{
    NSLog(@"对方的ip地址为：%@",host);
}
//当有客户端请求连接的时候会进到此方法
-(void)onSocket:(AsyncSocket *)sock didAcceptNewSocket:(AsyncSocket *)newSocket{
    
    //需要把newSocket记住 不然newSocket就会被释放掉
    self.myNewSocket = newSocket;
    //有人进来了  就调用接收数据的方法
    [newSocket readDataWithTimeout:-1 tag:0];
}
//读到数据的时候会进到此方法
-(void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    NSString *info = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"接收到客户端的数据：-----%@",info);
}
//当连接断开的时候调用
-(void)onSocketDidDisconnect:(AsyncSocket *)sock{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
