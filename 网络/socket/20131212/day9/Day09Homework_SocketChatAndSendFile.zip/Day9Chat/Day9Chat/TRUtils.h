//
//  TRUtils.h
//  Day9Chat
//
//  Created by Tarena on 13-12-13.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRUtils : NSObject
+(NSMutableData *)getAllDataByHeaderString:(NSString*)header;
@end
