//
//  TRViewController.m
//  Day9Socket
//
//  Created by Tarena on 13-12-12.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()
@property (nonatomic, strong)AsyncSocket *serverSocket;
@property (nonatomic, strong)AsyncSocket *myNewSocket;
@property (nonatomic, strong)AsyncSocket *clientSocket;
@property (nonatomic, strong)NSMutableData *fileAllData;
@property (nonatomic) int fileLength;
@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //创建服务器
    self.serverSocket = [[AsyncSocket alloc]initWithDelegate:self];
    [self.serverSocket acceptOnPort:8000 error:nil];
    self.fileAllData = [NSMutableData data];
}
//当连接成功的时候调用 只要用于获取对方的ip
-(void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port{
    NSLog(@"对方的ip地址为：%@",host);
}
//当有客户端请求连接的时候会进到此方法
-(void)onSocket:(AsyncSocket *)sock didAcceptNewSocket:(AsyncSocket *)newSocket{
    
    //需要把newSocket记住 不然newSocket就会被释放掉
    self.myNewSocket = newSocket;
    //有人进来了  就调用接收数据的方法
    [newSocket readDataWithTimeout:-1 tag:0];
}
//读到数据的时候会进到此方法
-(void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    [self.fileAllData appendData:data];
    
    if (self.fileAllData.length == self.fileLength) {
         [self.fileAllData writeToFile:@"/Users/apple/Pictures/reciveFile/b.jpg" atomically:YES];
    }
    //继续读取后面的数据
    [sock readDataWithTimeout:-1 tag:0];
}









//客户端代码
- (IBAction)clicked:(id)sender {
    //    1.创建Socket对象
    self.clientSocket = [[AsyncSocket alloc]initWithDelegate:self];
    //2.请求建立连接
    [_clientSocket connectToHost:@"127.0.0.1"onPort:8000 error:nil];
    NSData *data = [NSData dataWithContentsOfFile:@"/Users/apple/Documents/iOS Core/2_Views/day13/Demo0_1_Gesture_Nib/Demo0_1_Gesture_Nib/Elephant.jpg"];
    self.fileLength = data.length;
    [_clientSocket writeData:data withTimeout:-1 tag:0];
   
}
-(void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag{
    NSLog(@"发送成功了！");
}





- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
