//
//  TRViewController.h
//  Day9MoviePlayer
//
//  Created by Tarena on 13-12-12.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
@interface TRViewController : UIViewController
@property (nonatomic, strong)MPMoviePlayerController *player;
@end
