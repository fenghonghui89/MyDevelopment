//
//  DGCUserInfo.m
//  AFNetworkTest
//
//  Created by 冯鸿辉 on 15/10/23.
//  Copyright © 2015年 hanyfeng. All rights reserved.
//

#import "DGCUserInfo.h"

@implementation DGCUserInfo

@end
