//
//  HFViewController.h
//  ASIHTTPRequest_SynGetAndPost
//
//  Created by hanyfeng on 14-7-1.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
@interface HFViewController : UIViewController

@end
