//
//  HFAppDelegate.h
//  ASIHTTPRequest_SynGetAndPost
//
//  Created by hanyfeng on 14-7-1.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
