//
//  HFViewController.m
//  ASIHTTPRequest_SynGetAndPost
//
//  Created by hanyfeng on 14-7-1.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import "HFViewController.h"

@interface HFViewController ()

@end

@implementation HFViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
#pragma mark GET
    NSString *pathGET = @"http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx/getWeather?theCityCode=江门&theUserID=";
    pathGET = [pathGET stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *urlGET = [NSURL URLWithString:pathGET];
    
    /*
     使用代码块可能会引起循环保持（互相retain造成无法释放），为解决这个问题，可以用以下关键字：
     __weak：适用于ARC
     __block：适用于MRC
     */
    __weak ASIHTTPRequest *requestGET = [ASIHTTPRequest requestWithURL:urlGET];

    [requestGET setCompletionBlock:^{
        NSData *data = [requestGET responseData];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"data:%@",str);
    }];
    
    [requestGET setFailedBlock:^{
        NSError *error = [requestGET error];
        NSLog(@"error:%@",[error localizedDescription]);
    }];
    
    [requestGET startAsynchronous];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
