//
//  HFViewController.m
//  HTTPQueue
//
//  Created by hanyfeng on 14-7-1.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import "HFViewController.h"

@interface HFViewController ()
@property(nonatomic,strong)ASINetworkQueue *networkQueue;
@end

@implementation HFViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)tap:(id)sender
{
    NSString *imagePath1 = @"http://img0.bdstatic.com/img/image/shouye/sjbztmxdg.jpg";
    NSString *imagePath2 = @"http://img0.bdstatic.com/img/image/shouye/xuruoxuan.jpg";
    NSArray *arr = @[imagePath1,imagePath2];
    
    
    if (!_networkQueue) {
        _networkQueue = [[ASINetworkQueue alloc] init];
    }
    
    //停止以前的队列
    [_networkQueue cancelAllOperations];
    
    //设置回调
    [_networkQueue setDelegate:self];
    [_networkQueue setRequestDidFinishSelector:@selector(requestFinished:)];
    [_networkQueue setRequestDidFailSelector:@selector(requestFinished:)];
    [_networkQueue setQueueDidFinishSelector:@selector(queueFinished:)];
    
    //创建队列
    for (int i = 0 ; i < arr.count; i++) {
        NSString *imagePath = arr[i];
        imagePath = [imagePath stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url = [NSURL URLWithString:imagePath];
        
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
        request.tag = i;//如果需要传递更多信息，可以用userInfo属性
        [_networkQueue addOperation:request];
    }
    
    [_networkQueue go];
}

#pragma mark - ASINetworkQueue自定义回调
- (void)requestFinished:(ASIHTTPRequest *)request
{
    NSData *data = [request responseData];
    UIImage *image = [UIImage imageWithData:data];
    
    if (request.tag == 0) {
        _myIV1.image = image;
    }else {
        _myIV2.image = image;
    }
    
    if ([_networkQueue requestsCount] == 0) {
        _networkQueue = nil;
    }
    
    NSLog(@"请求完成：%d",request.tag);
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSError *error = [request error];
    NSLog(@"error:%@",[error localizedDescription]);
}

- (void)queueFinished:(ASIHTTPRequest *)request
{
    if ([_networkQueue requestsCount] == 0) {
		[self setNetworkQueue:nil];
	}
    
    NSLog(@"队列完成");
}
@end
