//
//  HFViewController.h
//  HTTPQueue
//
//  Created by hanyfeng on 14-7-1.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASINetworkQueue.h"
#import "ASIHTTPRequest.h"
@interface HFViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *myIV1;
@property (weak, nonatomic) IBOutlet UIImageView *myIV2;


@end
