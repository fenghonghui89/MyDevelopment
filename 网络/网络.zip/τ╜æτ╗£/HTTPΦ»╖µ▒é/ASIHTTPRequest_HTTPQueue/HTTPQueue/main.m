//
//  main.m
//  HTTPQueue
//
//  Created by hanyfeng on 14-7-1.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HFAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HFAppDelegate class]));
    }
}
