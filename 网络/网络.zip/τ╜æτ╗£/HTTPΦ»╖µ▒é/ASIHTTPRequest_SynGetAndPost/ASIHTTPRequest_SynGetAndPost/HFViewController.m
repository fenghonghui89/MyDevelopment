//
//  HFViewController.m
//  ASIHTTPRequest_SynGetAndPost
//
//  Created by hanyfeng on 14-7-1.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import "HFViewController.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
@interface HFViewController ()

@end

@implementation HFViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
#pragma mark GET
    NSString *pathGET = @"http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx/getWeather?theCityCode=江门&theUserID=";
    pathGET = [pathGET stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *urlGET = [NSURL URLWithString:pathGET];
   
    ASIHTTPRequest *requestGET = [ASIHTTPRequest requestWithURL:urlGET];
    [requestGET startSynchronous];
    
    NSError *errorGET = [requestGET error];
    if (!errorGET) {
//        NSString *str = [requestGET responseString];
        NSData *data = [requestGET responseData];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",str);
    }
    
#pragma mark POST
    NSString* pathPOST = @"http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx/getWeather";
	NSURL* urlPOST = [NSURL URLWithString:pathPOST];
    ASIFormDataRequest *requestPOST = [ASIFormDataRequest requestWithURL:urlPOST];
    [requestPOST setPostValue:@"江门" forKey:@"theCityCode"];
    [requestPOST setPostValue:@"" forKey:@"theUserID"];
    [requestPOST startSynchronous];
    
    NSError *errorPOST = [requestPOST error];
    if (!errorPOST) {
        NSData *data = [requestPOST responseData];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",str);
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
