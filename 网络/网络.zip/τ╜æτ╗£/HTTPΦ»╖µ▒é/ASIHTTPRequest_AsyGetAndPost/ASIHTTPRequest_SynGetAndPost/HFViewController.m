//
//  HFViewController.m
//  ASIHTTPRequest_SynGetAndPost
//
//  Created by hanyfeng on 14-7-1.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import "HFViewController.h"

@interface HFViewController ()

@end

@implementation HFViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
#pragma mark GET
//    NSString *pathGET = @"http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx/getWeather?theCityCode=江门&theUserID=";
//    pathGET = [pathGET stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSURL *urlGET = [NSURL URLWithString:pathGET];
//    ASIHTTPRequest *requestGET = [ASIHTTPRequest requestWithURL:urlGET];
//    [requestGET setDelegate:self];
//    [requestGET startAsynchronous];
    
#pragma mark POST
    NSString* pathPOST = @"http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx/getWeather";
	NSURL* urlPOST = [NSURL URLWithString:pathPOST];
    ASIFormDataRequest *requestPOST = [ASIFormDataRequest requestWithURL:urlPOST];
    [requestPOST setDelegate:self];
    [requestPOST setPostValue:@"江门" forKey:@"theCityCode"];
    [requestPOST setPostValue:@"" forKey:@"theUserID"];
    [requestPOST startAsynchronous];
    
#pragma mark 自定义回调
//    [requestPOST setDidFinishSelector:@selector(requestSuccess:)];
//    [requestPOST setDidFailSelector:@selector(requestError:)];
//    [requestPOST startAsynchronous];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - ASIHTTPRequestDelegate
-(void)requestFinished:(ASIHTTPRequest *)request
{
    NSData *data = [request responseData];
    NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"data:%@",str);
}

-(void)requestFailed:(ASIHTTPRequest *)request
{
    NSError *error = [request error];
    NSLog(@"error:%@",[error localizedDescription]);
}

#pragma mark - 自定义ASIHTTPRequestDelegate
-(void)requestSuccess:(ASIHTTPRequest *)request
{
    NSData *data = [request responseData];
    NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"---data:%@",str);
}

-(void)requestError:(ASIHTTPRequest *)request
{
    NSError *error = [request error];
    NSLog(@"---error:%@",[error localizedDescription]);
}
@end
