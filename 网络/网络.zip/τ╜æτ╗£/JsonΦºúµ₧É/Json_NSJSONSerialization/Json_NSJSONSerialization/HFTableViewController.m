//
//  HFTableViewController.m
//  Json_NSJSONSerialization
//
//  Created by hanyfeng on 14-6-27.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import "HFTableViewController.h"

@interface HFTableViewController ()
@property(nonatomic,strong)NSMutableArray *notes;
@end

@implementation HFTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"Notes" ofType:@"json"];
    NSData *jsonData = [[NSData alloc] initWithContentsOfFile:path];
    NSError *error;
    id jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    /*
     NSJSONReadingMutableContainers = (1UL << 0),//指定解析返回的是可变数组或字典
     NSJSONReadingMutableLeaves = (1UL << 1),//叶节点是可变字符串
     NSJSONReadingAllowFragments = (1UL << 2)//顶级节点可以不是数组或字典
     */
    
    if (!jsonObj || error) {
        NSLog(@"JSON解码失败");
    }
    
    self.notes = [jsonObj objectForKey:@"Record"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - tableview delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.notes.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"  forIndexPath:indexPath];
    
    NSMutableDictionary *dict = self.notes[indexPath.row];
    cell.textLabel.text = [dict objectForKey:@"Content"];
    cell.detailTextLabel.text = [dict objectForKey:@"CDate"];
    
    return cell;
}

@end
