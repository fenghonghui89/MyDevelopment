//
//  HFTableViewController.m
//  Json_SBJson
//
//  Created by hanyfeng on 14-6-27.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import "HFTableViewController.h"
#import "SBJSON.h"

@interface HFTableViewController ()
@property(nonatomic,strong)NSMutableArray *notes;
@end

@implementation HFTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"Notes" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    
    //把获取到的数据转换成json字符串
    NSString *jsonStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    //解析json字符串
    NSDictionary *dic = [jsonStr JSONValue];
    
    self.notes = [dic objectForKey:@"Record"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - tableview delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.notes.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"  forIndexPath:indexPath];
    
    NSMutableDictionary *dict = self.notes[indexPath.row];
    cell.textLabel.text = [dict objectForKey:@"Content"];
    cell.detailTextLabel.text = [dict objectForKey:@"CDate"];
    
    return cell;
}


@end
