//
//  NotesNextiveJsonParser.m
//  Json_NXJsonSerializer
//
//  Created by hanyfeng on 14-6-27.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import "NotesNextiveJsonParser.h"
#import "NXJsonParser.h"
@implementation NotesNextiveJsonParser
-(void)start
{
    
    NSString* path = [[NSBundle mainBundle] pathForResource:@"Notes" ofType:@"json"];
    NSData *jsonData = [[NSData alloc] initWithContentsOfFile:path];
    NXJsonParser *jsonParser = [[NXJsonParser alloc] initWithData:jsonData];
    id jsonObj = [jsonParser parse:nil ignoreNulls:NO];
	
    if (!jsonObj) {
        NSLog(@"JSON数据解析失败。");
        return;
    }
    
    self.notes = [jsonObj objectForKey:@"Record"];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadViewNotification" object:self.notes userInfo:nil];
    
    self.notes = nil;
    
}
@end
