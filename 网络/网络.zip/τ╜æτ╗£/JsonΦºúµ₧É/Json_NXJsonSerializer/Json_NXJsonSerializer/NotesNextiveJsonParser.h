//
//  NotesNextiveJsonParser.h
//  Json_NXJsonSerializer
//
//  Created by hanyfeng on 14-6-27.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NotesNextiveJsonParser : NSObject
//解析出的数据内部是字典类型
@property (strong,nonatomic) NSMutableArray *notes;

//开始解析
-(void)start;
@end
