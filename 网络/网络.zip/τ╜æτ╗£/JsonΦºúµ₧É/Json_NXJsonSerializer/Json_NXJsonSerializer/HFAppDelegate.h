//
//  HFAppDelegate.h
//  Json_NXJsonSerializer
//
//  Created by hanyfeng on 14-6-27.
//  Copyright (c) 2014年 hanyfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
