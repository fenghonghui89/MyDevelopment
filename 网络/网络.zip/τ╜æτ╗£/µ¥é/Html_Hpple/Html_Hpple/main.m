//
//  main.m
//  Html_Hpple
//
//  Created by wangan on 13-4-12.
//  Copyright (c) 2013年 com.wangan. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
