//
//  AppDelegate.h
//  Html_Hpple
//
//  Created by wangan on 13-4-12.
//  Copyright (c) 2013年 com.wangan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ExpatiationViewController;
@class HomeViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ExpatiationViewController *viewController;

@property (strong, nonatomic) HomeViewController *homeViewcontroller;

@end
