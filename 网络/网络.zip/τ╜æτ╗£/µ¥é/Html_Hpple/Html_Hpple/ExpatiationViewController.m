//
//  ViewController.m
//  Html_Hpple
//
//  Created by wangan on 13-4-12.
//  Copyright (c) 2013年 com.wangan. All rights reserved.
//

#import "ExpatiationViewController.h"

@interface ExpatiationViewController ()

@end

@implementation ExpatiationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

@end
