//
//  AppDelegate.h
//  TestParseHTML
//
//  Created by Adam on 13-10-8.
//  Copyright (c) 2013年 Adam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
