//
//  DGCBaseModel.h
//  AFNetworkTest
//
//  Created by 冯鸿辉 on 15/10/23.
//  Copyright © 2015年 hanyfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DGCBaseModel : NSObject
@property(nonatomic,assign) NSInteger pageCount;//总页数
@property(nonatomic,assign) NSInteger listCount;//总条数
@end
