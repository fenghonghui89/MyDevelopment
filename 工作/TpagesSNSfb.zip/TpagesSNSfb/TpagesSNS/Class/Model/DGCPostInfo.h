//
//  DGCPostInfo.h
//  TpagesSNS
//
//  Created by 冯鸿辉 on 15/10/27.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DGCBaseModel.h"
#import "DGCDefine.h"
@interface DGCPostInfo : DGCBaseModel
PROPERTY_NON_ATOMIC_ASSIGN NSInteger postId;
PROPERTY_NON_ATOMIC_ASSIGN NSInteger site;
PROPERTY_NON_ATOMIC_ASSIGN NSInteger host;
PROPERTY_NON_ATOMIC_ASSIGN NSInteger type;
PROPERTY_NON_ATOMIC_COPY NSString *user;
PROPERTY_NON_ATOMIC_COPY NSString *emote;
PROPERTY_NON_ATOMIC_ASSIGN NSInteger num_likes;
PROPERTY_NON_ATOMIC_ASSIGN NSInteger num_shares;
PROPERTY_NON_ATOMIC_ASSIGN NSInteger num_comments;
PROPERTY_NON_ATOMIC_COPY NSString *url;
PROPERTY_NON_ATOMIC_COPY NSString *updated_time;

PROPERTY_NON_ATOMIC_COPY NSString *detail;
PROPERTY_NON_ATOMIC_COPY NSString *area;

@end
