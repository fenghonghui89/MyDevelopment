//
//  DGCListModel.h
//  TpagesSNS
//
//  Created by 冯鸿辉 on 15/10/27.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import "DGCBaseModel.h"
#import "DGCDefine.h"
@interface DGCListInfo : DGCBaseModel
PROPERTY_NON_ATOMIC_STRONG NSArray *posts;
@end
