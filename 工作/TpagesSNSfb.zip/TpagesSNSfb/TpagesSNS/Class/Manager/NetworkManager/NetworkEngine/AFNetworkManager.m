//
//  AFNetworkManager.m
//  AFNetworkTest
//
//  Created by hanyfeng on 15/9/28.
//  Copyright © 2015年 hanyfeng. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "AFNetworkManager.h"

#import "AFNetworking.h"
#import "DGCTool.h"
#import "DGCUserInfo.h"
#import "DGCServerCallBackDelegate.h"

#import "DGCPostInfo.h"
#import "DGCListInfo.h"
@interface AFNetworkManager()

@end
@implementation AFNetworkManager
+(AFNetworkManager *)share
{
    static AFNetworkManager *share = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        share = [[self alloc] init];
    });
    return share;
}

/**
 *  1.登录
 *
 *  @param username     用户名
 *  @param password     密码
 *  @param sysmodel     系统类型
 *  @param deviceId     设备id
 *  @param userinfo     自定义信息
 *  @param successBlock 成功回调
 *  @param failerBlock  失败回调
 */
-(void)loginByUsername:(NSString *)username
              password:(NSString *)password
              sysmodel:(NSInteger)sysmodel
              userinfo:(NSDictionary *)userinfo
       successCallBack:(DGCServiceSuccessBlock)successBlock
        failerCallBack:(DGCServiceFailedBlock)failerBlock;
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSString *requestURL = @"http://51uca.com/biz/login";
    NSString *md5_password = [DGCTool md5:password];
    NSString *md5_tmp = [md5_password stringByAppendingString:@"rickyhoxiaoyi@163.com"];
    NSString *md5_final = [DGCTool md5:md5_tmp];
    
    NSDictionary *paraDic = @{@"username":username,
                              @"password":md5_final,
                              @"sysModel":@(sysmodel),
                              };

    [manager POST:requestURL parameters:paraDic success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
        NSInteger errorCode = [[dic objectForKey:@"status"] integerValue];
        
        if (errorCode == DGCRequestErrorCodeSuccess) {
            NSDictionary * infoDict = [dic objectForKey:@"data"];
            DGCUserInfo * uf = nil;
            if(infoDict){
                //创建实体
                uf = [DGCUserInfo new];
                
                //typeList
                id typeList = [infoDict objectForKey:@"typeList"];
                if ([typeList isKindOfClass:[NSArray class]]) {
                    if (((NSArray *)typeList).count > 0) {
                        uf.typeList = (NSArray *)typeList;
                    }
                }
                
                //loginAccount
                NSDictionary *loginAccountDic = [infoDict objectForKey:@"loginAccount"];
                uf.userId = [[loginAccountDic objectForKey:@"userId"] integerValue];
                uf.userName = [loginAccountDic objectForKey:@"userName"];
                uf.icon = [loginAccountDic objectForKey:@"icon"];
                uf.token = [loginAccountDic objectForKey:@"token"];
            }

            successBlock(uf,userinfo);
        }else{
            NSString *msg = [dic objectForKey:@"errMsg"];
            failerBlock(errorCode,msg,userinfo);
        }
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        failerBlock(-100,@"网络错误",userinfo);
    }];
}

/**
 *  最近更新帖子列表
 *
 *  @param since        从哪张帖子之后的帖子
 *  @param before       从哪张帖子之前的帖子
 *  @param per_page     返回几条记录，默认为`5`
 *  @param site         可选，帖子所在站点ID，默认为当前站点
 *  @param host         可选，帖子所属主体ID
 *  @param type         可选，帖子所属类型ID
 *  @param user         可选，发帖人用户ID
 *  @param userinfo     自定义信息
 *  @param successBlock 成功回调
 *  @param failerBlock  失败回调
 */
-(void)getPostsBySince:(NSInteger)since
                before:(NSInteger)before
              per_page:(NSInteger)per_page
                  site:(NSInteger)site
                  host:(NSInteger)host
                  type:(NSInteger)type
                  user:(NSInteger)user
              userinfo:(NSDictionary *)userinfo
       successCallBack:(DGCServiceSuccessBlock)successBlock
        failerCallBack:(DGCServiceFailedBlock)failerBlock
{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:DGCBaseURL]];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.requestSerializer.timeoutInterval = 20;
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.securityPolicy.allowInvalidCertificates = true;
    
    [manager GET:@"/posts" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array = (NSArray *)responseObject;
        NSLog(@"arr:%@",array);
        
        NSMutableArray *newArray = [NSMutableArray array];
        DGCListInfo *listInfo = [DGCListInfo new];
        for (NSDictionary *dic in array) {
            DGCPostInfo *postInfo = [DGCPostInfo new];
            postInfo.user = [dic objectForKey:@"user"];
            postInfo.url = [dic objectForKey:@"url"];
            postInfo.updated_time = [dic objectForKey:@"updated_time"];
            postInfo.area = @"假设广州";
            postInfo.detail = arc4random()%3 == 1?@"":@"啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊";
            [newArray addObject:postInfo];
        }
        listInfo.posts = newArray;
        successBlock(listInfo,userinfo);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        failerBlock(-100,@"网络错误",userinfo);
    }];
}

@end
