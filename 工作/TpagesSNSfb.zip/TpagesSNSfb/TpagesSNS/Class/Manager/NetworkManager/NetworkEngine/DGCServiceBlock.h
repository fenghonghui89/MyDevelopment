//
//  TGServiceBlock.h
//  WenDa
//
//  Created by keven on 14-11-18.
//  Copyright (c) 2014年 天工网络科技有限公司. All rights reserved.
//
#ifndef DGCServiceBlock_h
#define DGCServiceBlock_h
//#import "DGCDefine.h"
//#import "DGCBaseModel.h"
//
//typedef void (^DGCServiceSuccessBlock)(DGCBaseModel *baseModel,NSDictionary *userInfo);
//
//typedef void (^DGCServiceFailedBlock)(DGCRequestErrorCode code,NSString *msg, NSDictionary *userInfo);

#endif
