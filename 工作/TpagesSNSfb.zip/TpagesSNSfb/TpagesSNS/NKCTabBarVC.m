//
//  NKCTabBarVC.m
//  TpagesSNS
//
//  Created by 冯鸿辉 on 15/10/26.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import "NKCTabBarVC.h"
#import "NKCLoginVC.h"
@interface NKCTabBarVC ()

@end

@implementation NKCTabBarVC

- (void)viewDidLoad {
    [super viewDidLoad];
//    // Do any additional setup after loading the view.
//    
//    NKCLoginVC *lvc = [[NKCLoginVC alloc] initWithNibName:@"NKCLoginVC" bundle:nil];
//    UIWindow * keyWindow = [UIApplication sharedApplication].keyWindow;
//    [keyWindow.rootViewController presentViewController:lvc animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
