//
//  UILabel+TextFrame.m
//  TpagesS
//
//  Created by KongNear on 15/9/17.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import "UILabel+TextFrame.h"

@implementation UILabel (TextFrame)
/** 返回内容所占的高度
 *
 */
- (CGSize)boundingRectWithSize:(CGSize)size{
    NSDictionary *attribute = @{NSFontAttributeName: self.font};
    CGSize retSize = [self.text boundingRectWithSize:size
                                             options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin |NSStringDrawingUsesFontLeading
                                          attributes:attribute
                                             context:nil].size;
    return retSize;
}

/** 自动设置label的frame
 *
 */
- (void)boundingHeightAutoWithRect:(CGRect)rect lineNum:(NSUInteger)lineNum{
    self.numberOfLines = lineNum;
    rect.size.height = 200;
    CGRect newRect = [self textRectForBounds:rect limitedToNumberOfLines:lineNum];
    newRect.size.height += 4;
    if (lineNum) {
        CGSize newSize = [self boundingRectWithSize:rect.size];
        if (newSize.height < newRect.size.height) {
            newRect.size.height = newSize.height;
        }
    }
    self.frame = newRect;
}


@end
