//
//  UILabel+TextFrame.h
//  TpagesS
//
//  Created by KongNear on 15/9/17.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (TextFrame)
/** 返回内容所占的高度
 *      retrun:size of text by now size
 *      param:now size,just the width
 */
- (CGSize)boundingRectWithSize:(CGSize)size;

/** 自动设置label的frame
 *  param   rect:the label frame
 *          lineNum:max line num
 */
- (void)boundingHeightAutoWithRect:(CGRect)rect lineNum:(NSUInteger)lineNum;
@end
