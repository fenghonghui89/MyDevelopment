//
//  NKCPersonalPosCell.m
//  TpagesSNS
//
//  Created by KongNear on 15/9/24.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import "NKCPersonalPosCell.h"

@implementation NKCPersonalPosCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
