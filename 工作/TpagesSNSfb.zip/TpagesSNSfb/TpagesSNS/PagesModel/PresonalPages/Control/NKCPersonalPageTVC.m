//
//  NKCPersonalPage.m
//  TpagesSNS
//
//  Created by KongNear on 15/9/24.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

//  TODO:   此处为临时加载的图片、信息等。
//  正式开发时，删除此块，即可直接定位报错信息
#define tempName @"Near"
#define tempName0 @"temp_name_2"
#define tempName1 @"temp_name_3"
#define tempName2 @"temp_name_4"
#define tempName3 @"temp_name_5"
#define tempDeatil @"Near萌萌哒"


#define NKCPersonalPostCellIdentifier @"NKCPersonalPostCellIdentifier"
#define NKCPersonalBookmarkCellIdentifier @"NKCPersonalBookmarkCellIdentifier"
#define NKCPersonalFollowCellIdentifier @"NKCPersonalFollowCellIdentifier"

#import "NKCPersonalPageTVC.h"
#import "NKCPersonalPosCell.h"
#import "NKCSearchArticleCell.h"

@interface NKCPersonalPageTVC () <UITableViewDataSource, UITableViewDelegate>

@end

@implementation NKCPersonalPageTVC
#pragma mark - Class Loading
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    UITableView *tableView = (UITableView *)self.view;
    tableView.tableHeaderView = self.personalHeaderView;
    
    UINib *nib = [UINib nibWithNibName:@"NKCPersonalPosCell" bundle:nil];
    [tableView registerNib:nib forCellReuseIdentifier:NKCPersonalPostCellIdentifier];
    
    nib = [UINib nibWithNibName:@"NKCSearchArticleCell" bundle:nil];
    [tableView registerNib:nib forCellReuseIdentifier:NKCPersonalBookmarkCellIdentifier];
//
//    nib = [UINib nibWithNibName:@"NKCPersonalFollowCell" bundle:nil];
//    [tableView registerNib:nib forCellReuseIdentifier:NKCPersonalFollowCellIdentifier];
    
    _personalCurrentType = NKCPersonalTypePost;
}

- (UIView *)personalHeaderView{
    if (!_personalHeaderView) {
        [[NSBundle mainBundle] loadNibNamed:@"NKCPersonalHeaderV" owner:self options:nil];
    }
    return _personalHeaderView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.personalCurrentType == NKCPersonalTypePost) {
        NKCPersonalPosCell *cellPost = [tableView dequeueReusableCellWithIdentifier:NKCPersonalPostCellIdentifier forIndexPath:indexPath];
        [cellPost.personalPostLeftButton setImage:[UIImage imageNamed:tempName0] forState:UIControlStateNormal];
        [cellPost.personalPostMiddleButton setImage:[UIImage imageNamed:tempName2] forState:UIControlStateNormal];
        [cellPost.personalPostRightButton setImage:[UIImage imageNamed:tempName1] forState:UIControlStateNormal];
        return cellPost;
    }
    else if (self.personalCurrentType == NKCPersonalTypeBookmark){
        NKCSearchArticleCell *cellBookmark = [tableView dequeueReusableCellWithIdentifier:NKCPersonalBookmarkCellIdentifier forIndexPath:indexPath];
        
        cellBookmark.searchPostImageView.image = [UIImage imageNamed:tempName0];
        cellBookmark.searchUserImageView.image = [UIImage imageNamed:tempName1];
        cellBookmark.searchPostDetailLabel.text = tempDeatil;
        cellBookmark.searchUserLabel.text = tempName;
        
        return cellBookmark;
    
    }
    else if (self.personalCurrentType == NKCPersonalTypeFollow){
        UITableViewCell *cellFollow = [tableView dequeueReusableCellWithIdentifier:NKCPersonalFollowCellIdentifier];
        if(cellFollow== nil){
            cellFollow=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:NKCPersonalFollowCellIdentifier];
        }
        cellFollow.imageView.image = [UIImage imageNamed:tempName3];
        cellFollow.textLabel.text = tempName;
        
        return cellFollow;
    }
    
    return nil;
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (self.personalCurrentType) {
        case NKCPersonalTypePost:
            return (self.view.bounds.size.width - 16) / 3;
            break;
        case NKCPersonalTypeBookmark:
            return 140;
            break;
        case NKCPersonalTypeFollow:
            return 80;
            break;
        default:
            break;
    }
    return 80;
}

#pragma mark - Action
- (IBAction)personalTypeChange:(id)sender {
    UISegmentedControl *segment = (UISegmentedControl *)sender;
    switch (segment.selectedSegmentIndex) {
        case NKCPersonalTypePost:
            self.personalCurrentType = NKCPersonalTypePost;
            break;
        case NKCPersonalTypeBookmark:
            self.personalCurrentType = NKCPersonalTypeBookmark;
            break;
        case NKCPersonalTypeFollow:
            self.personalCurrentType = NKCPersonalTypeFollow;
            break;
        default:
            self.personalCurrentType = NKCPersonalTypePost;
            break;
    }
    [((UITableView *)self.view) reloadData];
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
