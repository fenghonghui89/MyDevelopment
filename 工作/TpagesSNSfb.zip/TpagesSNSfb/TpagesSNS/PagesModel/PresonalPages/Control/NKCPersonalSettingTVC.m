//
//  NKCPersonalSettingTVC.m
//  TpagesSNS
//
//  Created by KongNear on 15/9/24.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#define NKCPersonalSettingCellIdentifier @"NKCPersonalSettingCellIdentifier"

#import "NKCPersonalSettingTVC.h"
#import "NKCPersonalDetailVC.h"

@interface NKCPersonalSettingTVC () <UITableViewDataSource, UITableViewDelegate>

/** 数据源数组
 *  第一维：section;
 *  第二维：第一个为Header标题，剩下为cell;
 */
@property (nonatomic, strong) NSArray *personalDateSourceArray;

@end

@implementation NKCPersonalSettingTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray *array0 = @[@"个人账户", @"编辑个人资料", @"已绑定账号", @"通知", @"登出"];
    NSArray *array1 = @[@"关注好友", @"查找 TPAGES 好友", @"邀请好友"];
    NSArray *array2 = @[@"关于 TPAGES ", @"条款", @"私隐政策"];
    self.personalDateSourceArray = @[array0, array1, array2];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _personalDateSourceArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return ((NSArray *)[_personalDateSourceArray objectAtIndex:section]).count - 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NKCPersonalSettingCellIdentifier];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NKCPersonalSettingCellIdentifier];
    }
    
    cell.textLabel.text = [((NSArray *)[_personalDateSourceArray objectAtIndex:indexPath.section]) objectAtIndex:(indexPath.row + 1)];
    UISwitch *switchControl = nil;
    
    return cell;

}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [[_personalDateSourceArray objectAtIndex:section] objectAtIndex:0];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0 && indexPath.row == 0) {
        NKCPersonalDetailVC *personalDetail = [[NKCPersonalDetailVC alloc] init];
        [self.navigationController pushViewController:personalDetail animated:TRUE];
    }
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
