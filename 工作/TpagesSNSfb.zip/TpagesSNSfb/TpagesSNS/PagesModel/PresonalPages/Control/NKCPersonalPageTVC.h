//
//  NKCPersonalPage.h
//  TpagesSNS
//
//  Created by KongNear on 15/9/24.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger, NKCPersonalType) {
    NKCPersonalTypePost,
    NKCPersonalTypeBookmark,
    NKCPersonalTypeFollow
};

@interface NKCPersonalPageTVC : UITableViewController

@property (strong, nonatomic) IBOutlet UIView *personalHeaderView;
@property (weak, nonatomic) IBOutlet UIImageView *personalHeaderImageView;
@property (weak, nonatomic) IBOutlet UILabel *personalHeaderNameLabel;
@property (weak, nonatomic) IBOutlet UISegmentedControl *personalHeaderSegment;
@property (weak, nonatomic) IBOutlet UIButton *personalHeaderLeftButton;
@property (weak, nonatomic) IBOutlet UIButton *personalHeaderMiddleButton;
@property (weak, nonatomic) IBOutlet UIButton *personalHeaderRigheButton;

@property (nonatomic, assign) NKCPersonalType personalCurrentType;

@end
