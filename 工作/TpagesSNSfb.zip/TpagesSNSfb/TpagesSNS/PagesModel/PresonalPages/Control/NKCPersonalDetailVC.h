//
//  NKCPersonalDetailVC.h
//  TpagesSNS
//
//  Created by KongNear on 15/9/24.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCPersonalDetailVC : UIViewController

@end
