//
//  NKCShareDetailV.h
//  TpagesSNS
//
//  Created by NearKong on 15/10/6.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCShareDetailV : UIView

@end
