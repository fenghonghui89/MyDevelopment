//
//  AVCamPreviewView.h
//  TpagesSNS
//
//  Created by NearKong on 15/10/5.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AVCaptureSession;

@interface AVCamPreviewView : UIView
@property (nonatomic) AVCaptureSession *session;
@end
