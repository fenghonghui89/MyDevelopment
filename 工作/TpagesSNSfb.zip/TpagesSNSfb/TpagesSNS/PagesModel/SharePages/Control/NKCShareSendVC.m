//
//  NKCShareSendVC.m
//  TpagesSNS
//
//  Created by NearKong on 15/10/5.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#define NKCShareDetailBackgroundAlpha 0.9

#import "NKCShareSendVC.h"

@interface NKCShareSendVC ()

@property (nonatomic, copy) NSArray *imageViewArray;
@property (nonatomic, assign) BOOL isFinish;

@property (nonatomic, assign) BOOL pushBool;

@end

@implementation NKCShareSendVC

#pragma mark - < vc lifecycle > -
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //  source image
    _imageViewArray = @[_coverImageView, _imageView0, _imageView1, _imageView2, _imageView3];
    NSInteger imageNum = 0;
    for (UIImageView *imageViewSource in _sourceImageArray) {
        if (imageViewSource.image) {
            UIImageView *imageView = [_imageViewArray objectAtIndex:imageNum];
            imageView.image = imageViewSource.image;
            imageNum++;
        }
    }
    
    //  if send the message or go back
    _isFinish = FALSE;
    
    //  add detailScrollView
    self.detailScrollView.hidden = TRUE;
    [self uploadDetailView];
    _pushBool = false;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
//    self.tabBarController.tabBar.hidden = TRUE;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.tabBarController.tabBar.hidden = FALSE;
    if (_isFinish) {
        self.tabBarController.selectedIndex = 0;
    }
}

#pragma mark property View
- (UIView *)detailScrollView{
    if (!_detailScrollView) {
        // Load NKCShareDetailV.xib
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"NKCShareDetailV"
                                                       owner:self
                                                     options:nil];
    }
    return _detailScrollView;
}

- (UIView *)detail1View{
    if (!_detail1View) {
        // Load NKCShareDetailV.xib
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"NKCShareDetailV"
                                                       owner:self
                                                     options:nil];
    }
    return _detail1View;
}

- (UIView *)detail2View{
    if (!_detail2View) {
        // Load NKCShareDetailV.xib
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"NKCShareDetailV"
                                                       owner:self
                                                     options:nil];
    }
    return _detail2View;
}

#pragma mark Action
- (IBAction)shareInformation:(id)sender {
    _isFinish = TRUE;
    [self.navigationController popToRootViewControllerAnimated:false];
}

- (IBAction)pushDetailView:(id)sender {
    
    if (!self.pushBool) {
        self.detailScrollView.hidden = false;
        self.pushBool = true;
    }
    else{
        self.detailScrollView.hidden = true;
        self.pushBool = false;
    }
}

#pragma mark private Method
- (void)uploadDetailView{
    NSInteger retractWidth = 50;
    
    //  Add detailScrollView
    CGRect rect = self.view.bounds;
    rect.origin.x = retractWidth;
    rect.origin.y = rect.size.height - 302;
    rect.size = CGSizeMake(rect.size.width - retractWidth * 2, 302);
    self.detailScrollView.frame = rect;
    [self.view addSubview:self.detailScrollView];
    self.detailScrollView.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:NKCShareDetailBackgroundAlpha];
    self.detailScrollView.layer.cornerRadius = 8;
    self.detailScrollView.layer.masksToBounds = YES;
    
    //  Set shareDtaileScrollView subView
    rect = self.shareDtaileScrollView.bounds;
    rect.size.width = self.view.bounds.size.width - (8 + retractWidth) * 2;
    self.detail1View.frame = rect;
    [self.shareDtaileScrollView addSubview:self.detail1View];
    rect.origin.x = rect.size.width;
    self.detail2View.frame = rect;
    [self.shareDtaileScrollView addSubview:self.detail2View];
    
    rect.size.width *= 2;
    self.shareDtaileScrollView.contentSize = rect.size;
    
}

@end
