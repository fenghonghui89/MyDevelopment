//
//  NKCShareSendVC.h
//  TpagesSNS
//
//  Created by NearKong on 15/10/5.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCShareSendVC : UIViewController

//  storyBoard
@property (weak, nonatomic) IBOutlet UIImageView *coverImageView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView0;
@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
@property (weak, nonatomic) IBOutlet UIImageView *imageView2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView3;

@property (weak, nonatomic) IBOutlet UIView *discussDetailView;

//  detailView
@property (strong, nonatomic) IBOutlet UIView *detailScrollView;
@property (strong, nonatomic) IBOutlet UIView *detail1View;
@property (strong, nonatomic) IBOutlet UIView *detail2View;

@property (weak, nonatomic) IBOutlet UIScrollView *shareDtaileScrollView;

//  date Source
@property (weak, nonatomic) NSArray *sourceImageArray;

@end
