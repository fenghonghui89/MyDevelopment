//
//  NKCSharePageVC.h
//  TpagesSNS
//
//  Created by NearKong on 15/10/5.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCSharePageVC : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView0;
@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
@property (weak, nonatomic) IBOutlet UIImageView *imageView2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView3;
@property (weak, nonatomic) IBOutlet UIImageView *imageView4;

@property (weak, nonatomic) IBOutlet UIButton *imageButton0;
@property (weak, nonatomic) IBOutlet UIButton *imageButton1;
@property (weak, nonatomic) IBOutlet UIButton *imageButton2;
@property (weak, nonatomic) IBOutlet UIButton *imageButton3;
@property (weak, nonatomic) IBOutlet UIButton *imageButton4;

- (void)resetImageView;

@end
