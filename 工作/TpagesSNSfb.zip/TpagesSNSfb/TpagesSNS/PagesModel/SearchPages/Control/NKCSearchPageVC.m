//
//  NKCSearchPageVC.m
//  TpagesS
//
//  Created by KongNear on 15/9/15.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//


//  TODO:   此处为临时加载的图片、信息等。
//  正式开发时，删除此块，即可直接定位报错信息
#define tempPostImage @"temp_coffee"
#define tempPostDetail @"Near 系度舒服甘叹 coffee"
#define tempUesrImage @"temp_name_3"
#define tempUserDetail @"Near"

#define NKCSearchArticleCellIdentifier @"NKCSearchArticleCellIdentifier"
#define NKCSearchUserCellIdentifier @"NKCSearchUserCellIdentifier"
#define NKCSearchLocationCellIdentifier @"NKCSearchLocationCellIdentifier"

#import "NKCSearchPageVC.h"
#import "NKCSearchArticleCell.h"
#import "NKCSearchPageM.h"

#import "NKCHTTPRequestManager.h"

@interface NKCSearchPageVC () <UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITableView *searchTableView;
@property (weak, nonatomic) IBOutlet UITextField *searchField;
@property (weak, nonatomic) IBOutlet UIButton *searchButton;
@property (weak, nonatomic) IBOutlet UIButton *searchArticleButton;
@property (weak, nonatomic) IBOutlet UIButton *searchUserButton;
@property (weak, nonatomic) IBOutlet UIButton *searchLocationButton;

@property (nonatomic, strong) NSDictionary *searchTypeDictionary;
@property (nonatomic, assign) NKCSearchType searchCurrentType;
@property (nonatomic, strong) AFHTTPRequestOperationManager *baseAFManage;
@property (nonatomic, strong) NSMutableArray *dataSourceArray;

@end

@implementation NKCSearchPageVC

#pragma mark - Class Loading
- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    [self configUI];
    [self configData];
    [self configAF];
    
}

- (void)configUI{
    //  Sign up the cell identifier
    UINib *nib = [UINib nibWithNibName:@"NKCSearchArticleCell" bundle:nil];
    [self.searchTableView registerNib:nib forCellReuseIdentifier:NKCSearchArticleCellIdentifier];
    self.searchTableView.dataSource = self;
    self.searchTableView.delegate = self;
}

- (void)configData{
    //  Sign up dictionary with NKCSearchType as key and button as values
    self.dataSourceArray = [[NSMutableArray alloc] initWithCapacity:0];
    
    self.searchTypeDictionary = @{[NSNumber numberWithInteger:NKCSearchTypeArticle]:self.searchArticleButton, [NSNumber numberWithInteger:NKCSearchTypeUser]:self.searchUserButton, [NSNumber numberWithInteger:NKCSearchTypeLocation]:self.searchLocationButton};
}

- (void)configAF{
    self.baseAFManage = [[NKCHTTPRequestManager shareInstance] base_operationManager];
//    [self postListHttp:@"s"];
}

- (void)postListHttp:(NSString *)keyword{
    @weakify(self);
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObject:keyword forKey:@"s"];
    [self.baseAFManage GET:find_find parameters:dic success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"responseObject = \n%@", responseObject);
        @strongify(self);
        NSArray *array = (NSArray *)responseObject;
        NSArray *tmpCityArray = [MTLJSONAdapter modelsOfClass:NKCSearchPageM.class fromJSONArray:array error:nil];
        [self.dataSourceArray addObjectsFromArray:tmpCityArray];
//        [self.searchTableView reloadData];
        UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"返回结果"
                                                     message:[responseObject description]
                                                    delegate:nil
                                           cancelButtonTitle:@"确定"
                                           otherButtonTitles:nil];
        [av show];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error = \n%@", error);
        @strongify(self);
        
    }];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    //  each type have its own identifier cell
    if (self.searchCurrentType == NKCSearchTypeArticle || self.searchCurrentType == NKCSearchTypeLocation) {
        NKCSearchArticleCell *cellArticle = [tableView dequeueReusableCellWithIdentifier:NKCSearchArticleCellIdentifier forIndexPath:indexPath];
        cellArticle.searchPostDetailLabel.text = @"Near 好聪明哟！！";
        cellArticle.searchPostImageView.image = [UIImage imageNamed:tempPostImage];
        cellArticle.searchUserImageView.image = [UIImage imageNamed:tempUesrImage];
        cellArticle.searchPostDetailLabel.text = tempPostDetail;
        cellArticle.searchUserLabel.text = tempUserDetail;
        
        return cellArticle;
    }
    else if (self.searchCurrentType == NKCSearchTypeUser){
        UITableViewCell *cellUesr = [tableView dequeueReusableCellWithIdentifier:NKCSearchUserCellIdentifier];
        if(cellUesr== nil){
            cellUesr=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:NKCSearchUserCellIdentifier];
        }
        cellUesr.imageView.image = [UIImage imageNamed:tempPostImage];
        cellUesr.detailTextLabel.text = tempPostDetail;
        cellUesr.textLabel.text = tempUserDetail;
        return cellUesr;
    }
    else if (self.searchCurrentType == NKCSearchTypeLocation){
        UITableViewCell *cellLocation = [tableView dequeueReusableCellWithIdentifier:NKCSearchLocationCellIdentifier];
        if(cellLocation== nil){
            cellLocation=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:NKCSearchLocationCellIdentifier];
        }
        return cellLocation;
    }

    return nil;
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.searchCurrentType == NKCSearchTypeArticle) {
        return 134;
    }
    else if (self.searchCurrentType == NKCSearchTypeUser){
        return 80;
    }
    else if (self.searchCurrentType == NKCSearchTypeLocation){
        return 134;
    }
    return 80;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self removeFirstResponder];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self removeFirstResponder];
    [self postListHttp:textField.text];
    return true;
}

#pragma mark - Action
- (IBAction)searchAction:(id)sender {
    [self removeFirstResponder];
    [self postListHttp:self.searchField.text];
}

- (IBAction)searchSelectView:(id)sender{
    [self removeFirstResponder];
    
    UIButton *currentButton = (UIButton *)sender;
    NSNumber *currentNumber;
    for (NSNumber *number in self.searchTypeDictionary.allKeys) {
        if ([self.searchTypeDictionary objectForKey:number] == currentButton) {
            currentNumber = number;
            break;
        }
    }
    NKCSearchType currentType = [currentNumber integerValue];
    if (currentType == self.searchCurrentType) {
        return;
    }
    
    for (NSNumber *number in self.searchTypeDictionary.allKeys) {
        ((UIButton *)[self.searchTypeDictionary objectForKey:number]).selected = false;
    }
    
    self.searchCurrentType = currentType;
    currentButton.selected = TRUE;
    
    [self.searchTableView reloadData];

}

#pragma mark - private Method
- (void)removeFirstResponder{
    [self.searchField resignFirstResponder];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self removeFirstResponder];
}

@end
