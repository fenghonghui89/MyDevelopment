//
//  NKCSearchPageM.h
//  TpagesSNS
//
//  Created by NearKong on 15/10/25.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MTLModel.h"
#import <Mantle/MTLJSONAdapter.h>

@interface NKCSearchPageM : MTLModel <MTLJSONSerializing>

@property (nonatomic, strong, readonly) NSString *id;             // 整数，帖子ID
@property (nonatomic, strong, readonly) NSString *site;           // 整数，帖子所在站点ID，默认为当前站点
@property (nonatomic, strong, readonly) NSString *host;           // 整数，所属主体ID，可没有
@property (nonatomic, strong, readonly) NSString *type;           // 在相应语言中的帖子类别名称
@property (nonatomic, strong, readonly) NSString *user;           // 发帖人昵称
@property (nonatomic, strong, readonly) NSString *emote;          // 在相应语言中的帖子心情", 可没有
@property (nonatomic, strong, readonly) NSString *url;            // 帖子的URL
@property (nonatomic, strong, readonly) NSString *title;          // 标题
@property (nonatomic, strong, readonly) NSString *content;        // 帖子内容
@property (nonatomic, strong, readonly) NSString *num_likes;      // 整数，点赞总数
@property (nonatomic, strong, readonly) NSString *num_shares;     // 整数，分享总数
@property (nonatomic, strong, readonly) NSString *num_comments;   // 整数，评论总数
@property (nonatomic, strong, readonly) NSArray *pictures;       // 图片1URL
@property (nonatomic, strong, readonly) NSString *update_time;

@end
