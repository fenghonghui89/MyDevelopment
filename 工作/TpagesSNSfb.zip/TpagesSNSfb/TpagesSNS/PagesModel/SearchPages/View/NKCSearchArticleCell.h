//
//  NKCSearchArticleCell.h
//  TpagesSNS
//
//  Created by KongNear on 15/9/23.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCSearchArticleCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *searchPostImageView;
@property (weak, nonatomic) IBOutlet UIImageView *searchUserImageView;
@property (weak, nonatomic) IBOutlet UILabel *searchUserLabel;
@property (weak, nonatomic) IBOutlet UILabel *searchPostDetailLabel;

@end
