//
//  NKCSearchArticleCell.m
//  TpagesSNS
//
//  Created by KongNear on 15/9/23.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import "NKCSearchArticleCell.h"

@implementation NKCSearchArticleCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
