//
//  NKCLoginVC.h
//  TpagesSNS
//
//  Created by NearKong on 15/9/22.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCLoginVC : UIViewController

@end
