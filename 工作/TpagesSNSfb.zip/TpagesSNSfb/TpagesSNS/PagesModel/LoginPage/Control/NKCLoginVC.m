//
//  NKCLoginVC.m
//  TpagesSNS
//
//  Created by NearKong on 15/9/22.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import "NKCLoginVC.h"
#import "NKCLoginForgetPasscode.h"

@interface NKCLoginVC ()

@property (strong, nonatomic) IBOutlet UIView *loginSignInView;
@property (strong, nonatomic) IBOutlet UIView *loginSignUpView;

@property (weak, nonatomic) IBOutlet UISegmentedControl *loginSegment;

@end

@implementation NKCLoginVC
#pragma mark - Class Loading
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.loginSegment addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
    self.loginSignInView.hidden = FALSE;
    self.loginSignUpView.hidden = TRUE;
    CGRect rect = self.view.bounds;
    rect.origin.y = self.loginSegment.frame.origin.y + self.loginSegment.frame.size.height + 8;
    rect.size.height -= rect.origin.y;
    self.loginSignInView.frame = rect;
    self.loginSignUpView.frame = rect;
    [self.view addSubview:self.loginSignUpView];
    [self.view addSubview:self.loginSignInView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIView *)loginSignInView{
    if (!_loginSignInView) {
        // Load HeaderView.xib
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"NKCLoginSignInV"
                                                       owner:self
                                                     options:nil];
    }
    return _loginSignInView;
}

- (UIView *)loginSignUpView{
    if (!_loginSignUpView) {
        // Load HeaderView.xib
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"NKCLoginSignUpV"
                                                       owner:self
                                                     options:nil];
    }
    return _loginSignUpView;
}

#pragma mark - private Method
- (void)segmentAction:(UISegmentedControl *)segment{
    switch (segment.selectedSegmentIndex) {
        case 0:
            self.loginSignUpView.hidden = FALSE;
            self.loginSignInView.hidden = TRUE;
            break;
        case 1:
            self.loginSignUpView.hidden = TRUE;
            self.loginSignInView.hidden = FALSE;
            break;
        default:
            break;
    }
}

- (IBAction)forgetPasscode:(id)sender {
    NKCLoginForgetPasscode *forgetPasscode = [[NKCLoginForgetPasscode alloc] init];
    [self.navigationController pushViewController:forgetPasscode animated:TRUE];
}

@end
