//
//  NKCFindPageCell.m
//  TpagesS
//
//  Created by KongNear on 15/9/16.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import "NKCFindPageCell.h"
#import "UILabel+TextFrame.h"

@implementation NKCFindPageCell

- (void)awakeFromNib {
    // Initialization code
    self.findDetailLabel.lineBreakMode = NSLineBreakByTruncatingTail;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

/** 根据行数自动设置高度。
 *
 */
- (void)setDetailLabelHighWithLineNum:(NSUInteger)lineNum{
    self.findDetailLabel.numberOfLines = lineNum;
    [self.findDetailLabel boundingHeightAutoWithRect:self.findDetailLabel.frame lineNum:lineNum];
}

@end
