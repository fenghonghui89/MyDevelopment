//
//  NKCFindPageCell.h
//  TpagesS
//
//  Created by KongNear on 15/9/16.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCFindPageCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *findImageView;
@property (weak, nonatomic) IBOutlet UILabel *findTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *findDetailLabel;

/** 根据行数自动设置高度。
 *  set the num of line by max line num auto
 *      parame:max line num
 *  PS:若内容小于行数，以内容为准；若内容大于行数，设为最大行数。
 */
- (void)setDetailLabelHighWithLineNum:(NSUInteger)lineNum;

@end
