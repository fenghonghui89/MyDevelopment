//
//  NKCFindDetailVC.m
//  TpagesS
//
//  Created by KongNear on 15/9/16.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import "NKCFindDetailVC.h"

@interface NKCFindDetailVC ()

@end

@implementation NKCFindDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor blueColor];
    self.title = @"Find Detail";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
