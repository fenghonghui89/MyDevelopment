//
//  NKCFindPageVC.m
//  TpagesS
//
//  Created by KongNear on 15/9/15.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#define NKCFindPageCellIdentifier @"NKCFindPageCellIdentifier"
#define NKCFindPageDetailLineNum 3  //detail的最大行数

#import "NKCFindPageVC.h"
#import "NKCFindDetailVC.h"
#import "NKCFindPageCell.h"

@interface NKCFindPageVC () <UITableViewDataSource, UITableViewDelegate>

@end

#pragma mark - 
@implementation NKCFindPageVC
#pragma mark - Class Load Method
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    UINib *nib = [UINib nibWithNibName:@"NKCFindPageCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:NKCFindPageCellIdentifier];
    
    
//FIXME:Temp For dataSourceMa
    UIImage *image = [UIImage imageNamed:@"200.jpg"];
    NSDictionary *tempDictionary = [@{@"title":@"这是啥", @"detail":@"这个是detail啦。这次要长一点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点的哟", @"image":image} mutableCopy];
    NSDictionary *tempDictionary0 = [@{@"title":@"这是啥", @"detail":@"这个是detail啦。这次要长一点点点点点点点点的哟", @"image":image} mutableCopy];
    NSDictionary *tempDictionary1 = [@{@"title":@"这是啥", @"detail":@"这个是detail啦。这次要长一点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点点的哟", @"image":image} mutableCopy];

//    self.dataSourceMA = @[tempDictionary, tempDictionary, tempDictionary, tempDictionary, tempDictionary, tempDictionary];
    self.dataSourceMA = [@[tempDictionary, tempDictionary0, tempDictionary1] mutableCopy];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSourceMA.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NKCFindPageCell *cell = [tableView dequeueReusableCellWithIdentifier:NKCFindPageCellIdentifier];

    NSMutableDictionary *dataSourceDictionary = [self.dataSourceMA objectAtIndex:indexPath.row];
    cell.findTitleLabel.text = [dataSourceDictionary objectForKey:@"title"];
    cell.findDetailLabel.text = [dataSourceDictionary objectForKey:@"detail"];
    cell.findImageView.image = [dataSourceDictionary objectForKey:@"image"];
    
    [cell setDetailLabelHighWithLineNum:NKCFindPageDetailLineNum];
    float height = cell.findDetailLabel.frame.size.height + cell.findDetailLabel.frame.origin.y;
    [dataSourceDictionary setObject:[NSNumber numberWithFloat:height] forKey:@"height"];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NKCFindDetailVC *detail = [[NKCFindDetailVC alloc] init];
    [self.navigationController pushViewController:detail animated:TRUE];
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [(NSNumber *)[[self.dataSourceMA objectAtIndex:indexPath.row] objectForKey:@"height"] floatValue];
}


@end
