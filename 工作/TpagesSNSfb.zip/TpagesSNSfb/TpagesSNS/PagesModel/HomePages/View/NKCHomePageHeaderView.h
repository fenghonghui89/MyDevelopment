//
//  NKCHomePageHeaderView.h
//  TpagesSNS
//
//  Created by 冯鸿辉 on 15/10/26.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCHomePageHeaderView : UIView
@property (weak, nonatomic) IBOutlet UIButton *btn1;
@property (weak, nonatomic) IBOutlet UIButton *btn2;
@property (weak, nonatomic) IBOutlet UIButton *btn3;
@property (weak, nonatomic) IBOutlet UIButton *btn4;
@property (weak, nonatomic) IBOutlet UIButton *btn5;
@property (weak, nonatomic) IBOutlet UIButton *btn6;

@end
