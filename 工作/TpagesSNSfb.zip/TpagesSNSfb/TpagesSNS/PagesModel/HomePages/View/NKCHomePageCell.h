//
//  NKCHomePageCell.h
//  TpagesS
//
//  Created by NearKong on 15/9/15.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DGCPostInfo.h"
@class NKCHomePageCell;
@protocol homePageCellDelegate <NSObject>

- (void)homeJumpWithUserName:(NSString *)userName;
- (void)homeExpandDetail:(NKCHomePageCell *)cell;

@end

@interface NKCHomePageCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *homeOwnerImageView;
@property (weak, nonatomic) IBOutlet UILabel *homeOwnerName;
@property (weak, nonatomic) IBOutlet UILabel *homeSituation;

@property (weak, nonatomic) IBOutlet UIImageView *homePageImageView;
@property (weak, nonatomic) IBOutlet UILabel *homePageDetail;
@property (weak, nonatomic) IBOutlet UIImageView *homePageFavoriteImage;
@property (weak, nonatomic) IBOutlet UILabel *homePageFavoriteNum;
@property (weak, nonatomic) IBOutlet UIButton *homeExpandButton;

@property (weak, nonatomic) id<homePageCellDelegate> delegate;
@property(nonatomic,strong)DGCPostInfo *postInfo;
/** 根据行数自动设置高度。
 *  set the num of line by max line num auto
 *      parame:max line num
 *  PS:若内容小于行数，以内容为准；若内容大于行数，设为最大行数。
 */
- (void)setDetailLabelHighWithLineNum:(NSUInteger)lineNum;

+(CGFloat)heightForCellByContent:(NSString *)content;
@end
