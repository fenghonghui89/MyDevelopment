//
//  NKCHomePageCell.m
//  TpagesS
//
//  Created by NearKong on 15/9/15.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import "NKCHomePageCell.h"
#import "UILabel+TextFrame.h"
#import "UIImageView+AFNetworking.h"
#import "MDDefine.h"
#import "MDTool.h"
#import "UIView+MDCategory.h"
@interface NKCHomePageCell()
@property (weak, nonatomic) IBOutlet UIView *bgview;
@property (weak, nonatomic) IBOutlet UIView *headerbgview;
@property (weak, nonatomic) IBOutlet UIImageView *headerview;
@property (weak, nonatomic) IBOutlet UILabel *namelabel;
@property (weak, nonatomic) IBOutlet UILabel *timelabel;
@property (weak, nonatomic) IBOutlet UIView *imagebgview;
@property (weak, nonatomic) IBOutlet UIImageView *imagesview;
@property (weak, nonatomic) IBOutlet UIButton *imagebtn;
@property (weak, nonatomic) IBOutlet UIButton *imagebtn1;
@property (weak, nonatomic) IBOutlet UIButton *imagebtn2;
@property (weak, nonatomic) IBOutlet UIButton *imagebtn3;
@property (weak, nonatomic) IBOutlet UIButton *imagebtn4;
@property (weak, nonatomic) IBOutlet UIButton *bigimagebtn;
@property (weak, nonatomic) IBOutlet UILabel *detaillabel;
@property (weak, nonatomic) IBOutlet UIImageView *feelingview1;
@property (weak, nonatomic) IBOutlet UIImageView *feelingview2;
@property (weak, nonatomic) IBOutlet UIImageView *feelingview3;
@property (weak, nonatomic) IBOutlet UIView *bottombgview;
@property (weak, nonatomic) IBOutlet UIImageView *cateimageview;
@property (weak, nonatomic) IBOutlet UILabel *arealabel;
@property (weak, nonatomic) IBOutlet UIView *feelingbgview;
@property (weak, nonatomic) IBOutlet UIView *lineview;

//@property (strong, nonatomic)  UIView *bgview;
//@property (strong, nonatomic)  UIView *headerbgview;
//@property (strong, nonatomic)  UIImageView *headerview;
//@property (strong, nonatomic)  UILabel *namelabel;
//@property (strong, nonatomic)  UILabel *timelabel;
//@property (strong, nonatomic)  UIView *imagebgview;
//@property (strong, nonatomic)  UIImageView *imagesview;
//@property (strong, nonatomic)  UIButton *imagebtn;
//@property(strong,nonatomic)UIView *fourbtnbgview;
//@property (strong, nonatomic)  UIButton *imagebtn1;
//@property (strong, nonatomic)  UIButton *imagebtn2;
//@property (strong, nonatomic)  UIButton *imagebtn3;
//@property (strong, nonatomic)  UIButton *imagebtn4;
//@property (strong, nonatomic)  UIButton *bigimagebtn;
//@property (strong, nonatomic)  UILabel *detaillabel;
//@property (strong, nonatomic)  UIImageView *feelingview1;
//@property (strong, nonatomic)  UIImageView *feelingview2;
//@property (strong, nonatomic)  UIImageView *feelingview3;
//@property (strong, nonatomic)  UIView *bottombgview;
//@property (strong, nonatomic)  UIImageView *cateimageview;
//@property (strong, nonatomic)  UILabel *arealabel;
//@property (strong, nonatomic)  UIView *feelingbgview;
//@property (strong, nonatomic)  UIView *lineview;
@end

@implementation NKCHomePageCell

- (void)awakeFromNib
{
    [self customInitUI];
}

//-(void)customInitUI1
//{
//    UIView *bgview = [[UIView alloc] init];
//    [self.contentView addSubview:bgview];
//    _bgview = bgview;
//    
//    /*
//     headerbgview
//     */
//    UIView *headerbgview = [[UIView alloc] init];
//    [self.bgview addSubview:headerbgview];
//    _headerbgview = headerbgview;
//    
//    UIImageView *headerview = [[UIImageView alloc] init];
//    [self.headerbgview addSubview:headerbgview];
//    _headerview = headerview;
//    
//    UILabel *namelabel = [[UILabel alloc] init];
//    [self.headerbgview addSubview:namelabel];
//    _namelabel = namelabel;
//    
//    UILabel *timelabel = [[UILabel alloc] init];
//    [self.headerbgview addSubview:timelabel];
//    _timelabel = timelabel;
//    
//
//    /*
//     imagebgview
//     */
//    UIView *imagebgview = [[UIView alloc] init];
//    [_bgview addSubview:imagebgview];
//    _imagebgview = imagebgview;
//    
//    UIImageView *imagesview = [[UIImageView alloc] init];
//    [_imagebgview addSubview:imagesview];
//    _imagesview = imagesview;
//    
//    UIButton *imagebtn = [[UIButton alloc] init];
//    [_imagebgview addSubview:imagebtn];
//    _imagebtn = imagebtn;
//    
//    /*
//     4btnbgview
//     */
//    UIView *fourbtnbgview = [[UIView alloc] init];
//    [_bgview addSubview:fourbtnbgview];
//    _fourbtnbgview = fourbtnbgview;
//    
//    UIButton *imagebtn1 = [[UIButton alloc] init];
//    [_fourbtnbgview addSubview:imagebtn1];
//    _imagebtn1 = imagebtn1;
//    
//    UIButton *imagebtn2 = [[UIButton alloc] init];
//    [_fourbtnbgview addSubview:imagebtn2];
//    _imagebtn2 = imagebtn2;
//    
//    UIButton *imagebtn3 = [[UIButton alloc] init];
//    [_fourbtnbgview addSubview:imagebtn3];
//    _imagebtn3 = imagebtn3;
//    
//    UIButton *imagebtn4 = [[UIButton alloc] init];
//    [_fourbtnbgview addSubview:imagebtn4];
//    _imagebtn4 = imagebtn4;
//    
//    //detailLabel
//    UILabel *detailLabel = [[UILabel alloc] init];
//    [self.bgview addSubview:detailLabel];
//    _detaillabel = detailLabel;
//    
//    
//    /*
//     feelingBgView
//     */
//    UIView *feelingbgview = [[UIView alloc] init];
//    [_bgview addSubview:feelingbgview];
//    _feelingbgview = feelingbgview;
//    
//    UIImageView *feelingView1 = [[UIImageView alloc] init];
//    [_feelingbgview addSubview:feelingView1];
//    _feelingview1 = feelingView1;
//    
//    UIImageView *feelingView2 = [[UIImageView alloc] init];
//    [_feelingbgview addSubview:feelingView2];
//    _feelingview2 = feelingView2;
//    
//    UIImageView *feelingView3 = [[UIImageView alloc] init];
//    [_feelingbgview addSubview:feelingView3];
//    _feelingview3 = feelingView3;
//    
//    /*
//     buttomview
//     */
//    UIView *bottombgview = [[UIView alloc]init];
//    [_bgview addSubview:bottombgview];
//    _bottombgview = bottombgview;
//    
//    UIView *lineView = [[UIView alloc] init];
//    [_bottombgview addSubview:lineView];
//    _lineview = lineView;
//    
//    UIImageView *cateimageview = [[UIImageView alloc] init];
//    [bottombgview addSubview:cateimageview];
//    _cateimageview = cateimageview;
//    
//    UILabel *areaLabel = [[UILabel alloc] init];
//    [_bottombgview addSubview:areaLabel];
//    _arealabel = areaLabel;
//}
//
//
//-(void)customInitFrame
//{
//
//}

-(void)customInitUI
{
    [self setBackgroundColor:[UIColor clearColor]];
    [self.contentView setBackgroundColor:[UIColor clearColor]];
    [self.feelingview1.layer setCornerRadius:25];
    [self.feelingview2.layer setCornerRadius:25];
    [self.feelingview3.layer setCornerRadius:25];
    [self.layer setCornerRadius:5.0];
    [self setClipsToBounds:YES];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
}

/** 根据行数自动设置高度。
 *
 */
- (void)setDetailLabelHighWithLineNum:(NSUInteger)lineNum{
    self.homePageDetail.numberOfLines = lineNum;
    [self.homePageDetail boundingHeightAutoWithRect:self.homePageDetail.frame lineNum:lineNum];
}

-(void)setPostInfo:(DGCPostInfo *)postInfo
{
    _postInfo = postInfo;
    
    [self.namelabel setText:_postInfo.user];
    [self.timelabel setText:_postInfo.updated_time];
    [self.arealabel setText:_postInfo.area];
    
    
    if ([postInfo.detail isEqualToString:@""]) {
        [self.detaillabel setHeight_:0];
    }
    
    UIFont *fontBold = [UIFont fontWithName:@"Helvetica" size:17];
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.lineSpacing = 2;
    NSDictionary *dicsum = [NSDictionary dictionaryWithObjectsAndKeys:fontBold,NSFontAttributeName,style,NSParagraphStyleAttributeName,nil];
    NSAttributedString *astr = [[NSAttributedString alloc] initWithString:_postInfo.detail attributes:dicsum];
    [self.detaillabel setAttributedText:astr];
    
    [self.headerview setImageWithURL:[NSURL URLWithString:_postInfo.url] placeholderImage:[UIImage imageNamed:@"200*200.jpg"]];
    [self.cateimageview setImage:[UIImage imageNamed:@"200*200.jpg"]];
}

+(CGFloat)heightForCellByContent:(NSString *)content
{
    CGFloat headerbgviewH = 0;
    CGFloat imagebgViewH = 0;
    CGFloat feelingViewH = 0;
    CGFloat lineViewH = 0;
    CGFloat bottomViewH = 0;
    CGFloat spaceH = 0;
    CGFloat contentHeight = 0;
    CGFloat bgviewH = 0;
    CGFloat cellHeight = 0;
    
    if ([content isEqualToString:@""]) {
        contentHeight = 0;
        
        headerbgviewH = 60;
        imagebgViewH = 180;
        feelingViewH = 60;
        lineViewH = 5;
        bottomViewH = 50;
        spaceH = 4*10;
        
        bgviewH = contentHeight + headerbgviewH +imagebgViewH +feelingViewH +lineViewH +bottomViewH + spaceH;
        
        cellHeight = 5+bgviewH+5;
    }else{
        //设置字体和行距
        UIFont *fontBold = [UIFont fontWithName:@"Helvetica" size:17];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        style.lineSpacing = 2;
        NSDictionary *dicsum = [NSDictionary dictionaryWithObjectsAndKeys:fontBold,NSFontAttributeName,style,NSParagraphStyleAttributeName,nil];
        CGRect rect = [content boundingRectWithSize:CGSizeMake(screenW-5*2-10*2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:dicsum context:nil];
        contentHeight = rect.size.height;
        
        headerbgviewH = 60;
        imagebgViewH = 180;
        feelingViewH = 60;
        lineViewH = 5;
        bottomViewH = 50;
        spaceH = 4*10;
        bgviewH = contentHeight + headerbgviewH +imagebgViewH +feelingViewH +lineViewH +bottomViewH + spaceH;
        
        cellHeight = 5+bgviewH+5;

    }

    
    return cellHeight;
}

#pragma mark - < action > -

@end
