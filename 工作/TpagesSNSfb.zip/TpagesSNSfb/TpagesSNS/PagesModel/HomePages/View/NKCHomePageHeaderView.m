//
//  NKCHomePageHeaderView.m
//  TpagesSNS
//
//  Created by 冯鸿辉 on 15/10/26.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import "NKCHomePageHeaderView.h"
#import "UIView+MDCategory.h"
#import "MDTool.h"
#import "MDDefine.h"
@interface NKCHomePageHeaderView ()

@end
@implementation NKCHomePageHeaderView

-(void)awakeFromNib
{
    [self customInitUI];
}

-(void)customInitUI
{
    [self setSizew:screenW h:50];
}

@end
