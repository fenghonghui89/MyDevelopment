//
//  NKCHomeDetailTVC.h
//  TpagesSNS
//
//  Created by KongNear on 15/9/22.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NKCHomePagesM.h"

@interface NKCHomeDetailTVC : UITableViewController

- (instancetype)initWithHomePageM:(NKCHomePagesM *)homePagesM;

@end
