//
//  NKCHomePageVC.h
//  TpagesSNS
//
//  Created by 冯鸿辉 on 15/10/26.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NKCHomePageVC : UIViewController

@end
