//
//  NKCHomeDetailTVC.m
//  TpagesSNS
//
//  Created by KongNear on 15/9/22.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#define NKCHomeDetailCellIdentifier @"NKCHomeDetailCellIdentifier"
#define NKCHomeDetailViewTag 1101
#define NKCHomeDetailAlphaViewTag 1102
#define NKCHomeDetailImageViewTag 1111

#import "NKCHomeDetailTVC.h"
#import "NKCHTTPRequestManager.h"
#import "NKCHomeDetailM.h"

@interface NKCHomeDetailTVC () <UITableViewDataSource, UITableViewDelegate>

#pragma mark HeadView
@property (strong, nonatomic) IBOutlet UIView *homeDeatilHeadView;
@property (weak, nonatomic) IBOutlet UIImageView *homeDetailMainImageView;
@property (weak, nonatomic) IBOutlet UIImageView *homeDetailOtherImageView0;
@property (weak, nonatomic) IBOutlet UIImageView *homeDetailOtherImageView1;
@property (weak, nonatomic) IBOutlet UIImageView *homeDetailOtherImageView2;
@property (weak, nonatomic) IBOutlet UIImageView *homeDetailOtherImageView3;
@property (weak, nonatomic) IBOutlet UILabel *homeDetailMainLabel;
@property (weak, nonatomic) IBOutlet UILabel *homeDetailUserName;
@property (weak, nonatomic) IBOutlet UILabel *homeDetailReadNum;
@property (weak, nonatomic) IBOutlet UILabel *homeDetailLikeNum;


#pragma mark TableView
@property (strong, nonatomic) IBOutlet UITableView *homeDetailTableView;

#pragma mark Source
@property (nonatomic, copy) NSArray *imageArray;
@property (nonatomic, assign) NSInteger imageNum;

@property (nonatomic, strong) NKCHomePagesM *homePagesM;
@property (nonatomic, strong) NKCHomeDetailM *homeDetailM;
@property (nonatomic, strong) AFHTTPRequestOperationManager *baseAFManage;
@property (nonatomic, strong) NSMutableArray *dataSourceArray;

@end

@implementation NKCHomeDetailTVC

- (instancetype)initWithHomePageM:(NKCHomePagesM *)homePagesM{
    self = [super init];
    _homePagesM = homePagesM;
    return self;
}

#pragma mark - Class Loading
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configUI];
    [self configData];
    [self configAF];
}

- (void)configUI{
    self.homeDetailTableView.tableHeaderView = self.homeDeatilHeadView;
    [self addRecognizerToImageView];
}

- (void)configData{
    self.dataSourceArray = [[NSMutableArray alloc] initWithCapacity:0];
}

- (void)configAF{
    self.baseAFManage = [[NKCHTTPRequestManager shareInstance] base_operationManager];
    [self postListHttp];
}

- (void)postListHttp{
    @weakify(self);
    [self.baseAFManage GET:[NSString stringWithFormat:@"%@/%@", post_posts, self.homePagesM.id] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //        NSLog(@"responseObject = \n%@", responseObject);
        @strongify(self);
        NSArray *array = @[responseObject];
        NSArray *tmpCityArray = [MTLJSONAdapter modelsOfClass:NKCHomeDetailM.class fromJSONArray:array error:nil];
        self.homeDetailM = [tmpCityArray firstObject];
        [self.homeDetailTableView reloadData];
        [self updateHeadView];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        @strongify(self);
        NSLog(@"error = \n%@", error);
        UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"错误"
                                                     message:[NSString stringWithFormat:@"domain = %@", error.domain]
                                                    delegate:nil
                                           cancelButtonTitle:@"确定"
                                           otherButtonTitles:nil, nil];
        [av show];
        
    }];
}

//- (UIView *)homeDeatilHeadView{
//    if (!_homeDeatilHeadView) {
//        // Load HeaderView.xib
//        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"NKCHomeDetailHeaderV"
//                                                       owner:self
//                                                     options:nil];
//    }
//    return _homeDeatilHeadView;
//}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.tabBarController.tabBar setHidden:false];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NKCHomeDetailCellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:NKCHomeDetailCellIdentifier];
    }
    
    cell.imageView.image = [UIImage imageNamed:@"ooopic_1442889780"];
    cell.textLabel.text = @"Near";
    cell.detailTextLabel.text = @"Near 真是太帅了。";
    cell.detailTextLabel.numberOfLines = 0;
    cell.detailTextLabel.textAlignment = NSTextAlignmentLeft;
    
    return cell;
}

#pragma mark - UITableViewDelegate
//  此处主要是 cell 与 header 之间的间隔。
//  不直接设置 header 的高度是因为会出现一条灰色的横条
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return @"nil";
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return [[UIView alloc] init];
}

#pragma mark - Priavte Method
- (void)addRecognizerToImageView{
    NSArray *array = @[_homeDetailMainImageView, _homeDetailOtherImageView0, _homeDetailOtherImageView1, _homeDetailOtherImageView2, _homeDetailOtherImageView3];
    NSMutableArray *arrayTemp = [[NSMutableArray alloc] init];
    for (UIImageView *imageView in array) {
        if (imageView) {
            [arrayTemp addObject:imageView.image];
            
            imageView.userInteractionEnabled = YES;
            UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
            [imageView addGestureRecognizer:singleTap];
        }
    }
    _imageArray = arrayTemp;
}

- (void)updateHeadView{
    self.homeDetailUserName.text = self.homeDetailM.user;
    self.homeDetailMainLabel.text = self.homeDetailM.content;
    self.homeDetailReadNum.text = [NSString stringWithFormat:@"阅读 %@", self.homeDetailM.num_comments];
    self.homeDetailLikeNum.text = self.homeDetailM.num_likes;
    
//    @property (nonatomic, strong) NSString *id;             // 整数，帖子ID
//    @property (nonatomic, strong) NSString *site;           // 整数，帖子所在站点ID，默认为当前站点
//    @property (nonatomic, strong) NSString *host;           // 整数，所属主体ID，可没有
//    @property (nonatomic, strong) NSString *type;           // 在相应语言中的帖子类别名称
//    @property (nonatomic, strong) NSString *user;           // 发帖人昵称
//    @property (nonatomic, strong) NSString *emote;          // 在相应语言中的帖子心情", 可没有
//    @property (nonatomic, strong) NSString *url;            // 帖子的URL
//    @property (nonatomic, strong) NSString *title;          // 标题
//    @property (nonatomic, strong) NSString *content;        // 帖子内容
//    @property (nonatomic, strong) NSString *num_likes;      // 整数，点赞总数
//    @property (nonatomic, strong) NSString *num_shares;     // 整数，分享总数
//    @property (nonatomic, strong) NSString *num_comments;   // 整数，评论总数
//    @property (nonatomic, strong) NSArray *pictures;       // 图片1URL
//    @property (nonatomic, strong) NSString *update_time;
}

- (void)handleSingleTap:(UIGestureRecognizer *)gestureRecognizer {
    UIImage *image = ((UIImageView *)[gestureRecognizer view]).image;
    
//    add view
    UIView *alphaView = [[UIView alloc] initWithFrame:self.view.bounds];
    alphaView.tag = NKCHomeDetailAlphaViewTag;
    alphaView.alpha = 0.8;
    alphaView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:alphaView];
    
    CGRect cg = [UIScreen mainScreen].bounds;
    cg.size.height -= 100;
    UIView *view = [[UIView alloc] initWithFrame:cg];
    view.tag = NKCHomeDetailViewTag;
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:cg];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.image = image;
    imageView.tag = NKCHomeDetailImageViewTag;
    [view addSubview:imageView];
    
    UIButton *closeButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [closeButton addTarget:self action:@selector(closeView) forControlEvents:UIControlEventTouchUpInside];
    [closeButton setImage:[UIImage imageNamed:@"48*48"] forState:UIControlStateNormal];
    [view addSubview:closeButton];
    
    cg.origin.x = cg.size.width / 2 - 110;
    cg.origin.y = cg.size.height - 100;
    cg.size = CGSizeMake(60, 60);
    UIButton *leftButton = [[UIButton alloc] initWithFrame:cg];
    [leftButton addTarget:self action:@selector(leftView) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"ooopic_1442916592"] forState:UIControlStateNormal];
    leftButton.frame = cg;
    [view addSubview:leftButton];
    
    cg.origin.x = view.bounds.size.width / 2 + 50;
    UIButton *rightButton = [[UIButton alloc] initWithFrame:cg];
    [rightButton addTarget:self action:@selector(rightView) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"ooopic_1442916587"] forState:UIControlStateNormal];
    [view addSubview:rightButton];
    
    [self.view addSubview:view];
    
    //  select current image
    for (NSInteger i = 0; i < self.imageArray.count; i++) {
        UIImage *imageInArray = [self.imageArray objectAtIndex:i];
        if (imageInArray == image) {
            self.imageNum = i;
            break;
        }
    }
    
    //  set view Station
    [((UITableView *)self.view) setScrollEnabled:false];
    [self.tabBarController.tabBar setHidden:true];
}

- (void)closeView{
    UIView *view = [self.view viewWithTag:NKCHomeDetailAlphaViewTag];
    [view removeFromSuperview];
    
    view = [self.view viewWithTag:NKCHomeDetailViewTag];
    [view removeFromSuperview];
    
    [((UITableView *)self.view) setScrollEnabled:true];
    [self.tabBarController.tabBar setHidden:false];
//    self.tabBarController.
}

- (void)leftView{
    if (!self.imageNum) {
        self.imageNum = self.imageArray.count - 1;
    }
    else
        self.imageNum--;
    UIImage *image = [self.imageArray objectAtIndex:self.imageNum];
    ((UIImageView *)[[self.view viewWithTag:NKCHomeDetailViewTag] viewWithTag:NKCHomeDetailImageViewTag]).image = image;
}

- (void)rightView{
    if (self.imageNum == self.imageArray.count - 1) {
        self.imageNum = 0;
    }
    else
        self.imageNum++;
    UIImage *image = [self.imageArray objectAtIndex:self.imageNum];
    ((UIImageView *)[[self.view viewWithTag:NKCHomeDetailViewTag] viewWithTag:NKCHomeDetailImageViewTag]).image = image;
}


@end
