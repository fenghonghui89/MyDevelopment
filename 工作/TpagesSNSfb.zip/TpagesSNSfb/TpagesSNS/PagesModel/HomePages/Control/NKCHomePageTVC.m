//
//  NKCHomePageVC.m
//  TpagesS
//
//  Created by KongNear on 15/9/15.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

//  TODO:   此处为临时加载的图片、信息等。
//  正式开发时，删除此块，即可直接定位报错信息
#define temp_User @"temp_qiu.jpg"
#define temp_Near @"Near"
#define temp_Station @"9张图片 3小时"
#define temp_cat @"temp_cat.jpg"
#define temp_Detail @"Near真系靓仔，oh yeah"
#define temp_Detail1 @"Near真系靓仔，oh yeah\n我5会话你知，Near有几靓仔。\n因为佢真系好靓仔！！哇哈哈哈~~~\n仲好聪明添，哇哈哈~~~哇哈哈~~~哇哈哈~~~哇哈哈~~~哇哈哈~~~哇哈哈~~~哇哈哈~~~哇哈哈~~~"
#define temp_FI @"temp_name_4"
#define temp_Num @"156"

/** custem Cell Identifier
 *
 */
#define NKCHomePageCellIdentifier @"NKCHomePageCellIdentifier"
/** default Num of line
 *
 */
#define NKCHomePageDetailLineNum 0
/** default value of cell expanded station
 *  false   :not expanded
 *  true    :expanded, shoule be set when NKCHomePageDetailLineNum is 0,
 *          or without expandButton
 */
#define NKCHomePageExpand true

#import "NKCHomePageTVC.h"
#import "NKCHomeDetailTVC.h"
#import "NKCHomePageCell.h"
#import "NKCHomePagesM.h"

#import "NKCHTTPRequestManager.h"

#import "NKCHomePageHeaderView.h"

@interface NKCHomePageTVC () <UITableViewDataSource, UITableViewDelegate, homePageCellDelegate>

@property (nonatomic, strong) NSDictionary *homeCellStationDictionary;
@property (nonatomic, strong) AFHTTPRequestOperationManager *baseAFManage;
@property (nonatomic, strong) NSMutableArray *dataSourceArray;
@property (strong, nonatomic) IBOutlet UITableView *homeTabelView;

@end

@implementation NKCHomePageTVC

NSString *tempStr = temp_Detail1;

#pragma mark - < init > -
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self configUI];
    [self configData];
    [self configAF];
}

- (void)configUI
{
    UINib *nib = [UINib nibWithNibName:@"NKCHomePageCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:NKCHomePageCellIdentifier];
    
    UIImageView *bgIV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background-1.jpg"]];
    [self.tableView setBackgroundView:bgIV];
    
    NKCHomePageHeaderView *hphv = [[[NSBundle mainBundle] loadNibNamed:@"NKCHomePageHeaderView" owner:self options:nil] lastObject];
    [self.tableView setTableHeaderView:hphv];
    
}

- (void)configData
{
    //  set Cell Station by MutableArray
    //  each MutableArray have 1 object at least, so need not to estimate if its value is NSNotFound
    NSMutableArray *cellHeightMA = [@[@80] mutableCopy];
    NSMutableArray *cellLineNumMA = [@[@NKCHomePageDetailLineNum] mutableCopy];
    NSMutableArray *cellExpandMA = [NSMutableArray arrayWithObject:[NSNumber numberWithBool:NKCHomePageExpand]];
    self.homeCellStationDictionary = @{@"height":cellHeightMA, @"lineNum":cellLineNumMA, @"expand":cellExpandMA};
    self.dataSourceArray = [[NSMutableArray alloc] initWithCapacity:0];
}

- (void)configAF{
    self.baseAFManage = [[NKCHTTPRequestManager shareInstance] base_operationManager];
    [self postListHttp];
}

- (void)postListHttp{
    @weakify(self);
    [self.baseAFManage GET:post_posts parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"responseObject = \n%@", responseObject);
        @strongify(self);
        NSArray *array = (NSArray *)responseObject;
        NSArray *tmpCityArray = [MTLJSONAdapter modelsOfClass:NKCHomePagesM.class fromJSONArray:array error:nil];
        [self.dataSourceArray addObjectsFromArray:tmpCityArray];
        [self.homeTabelView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error = \n%@", error);
        @strongify(self);

    }];
    
//    [self.baseAFManage GET:post_posts parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSArray *array = (NSArray *)responseObject;
//        NSArray *tmpCityArray = [MTLJSONAdapter modelsOfClass:NKCHomePagesM.class fromJSONArray:array error:nil];
//        NSLog(@"me JSON: %@", array);
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"error:%@",error);
//    }];
}

#pragma mark - < callback > -
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSourceArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NKCHomePageCell *cell = [tableView dequeueReusableCellWithIdentifier:NKCHomePageCellIdentifier forIndexPath:indexPath];
    NKCHomePagesM *homeM = [self.dataSourceArray objectAtIndex:indexPath.row];
    
    //TODO: it should be changed to right value
    //  set cell detail
    cell.homeOwnerImageView.image = [UIImage imageNamed:temp_User];
    cell.homeOwnerName.text = homeM.user;
    cell.homeSituation.text = temp_Station;
    cell.homePageImageView.image = [UIImage imageNamed:temp_cat];
    cell.homePageDetail.text = homeM.title;
    cell.homePageFavoriteImage.image = [UIImage imageNamed:temp_FI];
    cell.homePageFavoriteNum.text = ([homeM.num_likes isEqualToString:@""] || homeM.num_likes == nil) ? @"0" : homeM.num_likes;
    
//    @property (nonatomic, strong) NSString *id;             // 整数，帖子ID
//    @property (nonatomic, strong) NSString *site;           // 整数，帖子所在站点ID，默认为当前站点
//    @property (nonatomic, strong) NSString *host;           // 整数，所属主体ID，可没有
//    @property (nonatomic, strong) NSString *type;           // 在相应语言中的帖子类别名称
//    @property (nonatomic, strong) NSString *user;           // 发帖人昵称
//    @property (nonatomic, strong) NSString *emote;          // 在相应语言中的帖子心情", 可没有
//    @property (nonatomic, strong) NSString *url;            // 帖子的URL
//    @property (nonatomic, strong) NSString *title;          // 标题
//    @property (nonatomic, strong) NSString *num_likes;      // 整数，点赞总数
//    @property (nonatomic, strong) NSString *num_shares;     // 整数，分享总数
//    @property (nonatomic, strong) NSString *num_comments;   // 整数，评论总数
//    @property (nonatomic, strong) NSArray *pictures;       // 图片1URL
//    @property (nonatomic, strong) NSString *update_time;
    
    cell.delegate = self;

    //  get the lineNum
    NSMutableArray *lineNumArray = [self.homeCellStationDictionary objectForKey:@"lineNum"];
    NSInteger cellLineNum = NKCHomePageDetailLineNum;
    if (indexPath.row < lineNumArray.count) {
        cellLineNum = [((NSNumber *)[lineNumArray objectAtIndex:indexPath.row]) integerValue];
    }
    
    //  get the expandFlag
    NSMutableArray *expandArray = [self.homeCellStationDictionary objectForKey:@"expand"];
    BOOL cellExpand = NKCHomePageExpand;
    if (indexPath.row < expandArray.count) {
        cellExpand = [((NSNumber *)[expandArray objectAtIndex:indexPath.row]) boolValue];
    }
    
    //  setting the height of cell
    [cell setDetailLabelHighWithLineNum:cellLineNum];
    float height = 360;
    if (!cellExpand) {
        height = cell.homePageDetail.frame.size.height + cell.homePageDetail.frame.origin.y + 8 + cell.homeExpandButton.bounds.size.height + 8;
        cell.homeExpandButton.hidden = false;
    }
    else{
        height = cell.homePageDetail.frame.size.height + cell.homePageDetail.frame.origin.y;
        cell.homeExpandButton.hidden = true;
    }
    
    //  recode the height by Array
    NSMutableArray *cellHeightMA = [self.homeCellStationDictionary objectForKey:@"height"];
    if (indexPath.row >= cellHeightMA.count) {
        for (NSInteger rows = cellHeightMA.count; rows <= indexPath.row; rows++) {
            [cellHeightMA addObject:@80];
        }
    }
    [cellHeightMA replaceObjectAtIndex:indexPath.row withObject:[NSNumber numberWithFloat:height]];
    
//    CGRect rect = cell.homeExpandButton.frame;
//    rect.origin.y = cell.homePageDetail.frame.origin.y + cell.homePageDetail.frame.size.height + 8;
//    cell.homeExpandButton.frame = rect;
//    [cell bringSubviewToFront:cell.homeExpandButton];
    
//    NSLog(@"%F,%F\n%F,%F", cell.homePageDetail.frame.origin.x, cell.homePageDetail.frame.origin.y, cell.homePageDetail.frame.size.width, cell.homePageDetail.frame.size.height);
//    NSLog(@"%F,%F\n%F,%F", cell.homeExpandButton.frame.origin.x, cell.homeExpandButton.frame.origin.y, cell.homeExpandButton.frame.size.width, cell.homeExpandButton.frame.size.height);
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    float height = 80;
    NSMutableArray *heightArray = [self.homeCellStationDictionary objectForKey:@"height"];
    if (indexPath.row < heightArray.count) {
        height = [((NSNumber *)[heightArray objectAtIndex:indexPath.row]) floatValue];
    }
    return height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NKCHomeDetailTVC *homeDetail = [[NKCHomeDetailTVC alloc] initWithHomePageM:[self.dataSourceArray objectAtIndex:indexPath.row]];
    [self.navigationController pushViewController:homeDetail animated:TRUE];
    
}

#pragma mark - homePageCellDelegate
- (void)homeJumpWithUserName:(NSString *)userName{
    self.tabBarController.selectedIndex = 3;
}

- (void)homeExpandDetail:(NKCHomePageCell *)cell{
    UITableView *tableView = (UITableView *)self.view;
    NSIndexPath *indexPath = [tableView indexPathForCell:cell];
//    [cell.homeExpandButton setHidden:true];
    
    //  set the expand
    NSMutableArray *cellExpand = [self.homeCellStationDictionary objectForKey:@"expand"];
    if (indexPath.row >= cellExpand.count) {
        for (NSInteger rows = cellExpand.count; rows <= indexPath.row; rows++) {
            [cellExpand addObject:[NSNumber numberWithBool:NKCHomePageExpand]];
        }
    }
    [cellExpand replaceObjectAtIndex:indexPath.row withObject:[NSNumber numberWithBool:true]];
    
    //  set the lineNum
    NSMutableArray *cellLineNum = [self.homeCellStationDictionary objectForKey:@"lineNum"];
    if (indexPath.row >= cellLineNum.count) {
        for (NSInteger rows = cellLineNum.count; rows <= indexPath.row; rows++) {
            [cellLineNum addObject:@NKCHomePageDetailLineNum];
        }
    }
    [cellLineNum replaceObjectAtIndex:indexPath.row withObject:[NSNumber numberWithInteger:0]];

    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    
}

@end
