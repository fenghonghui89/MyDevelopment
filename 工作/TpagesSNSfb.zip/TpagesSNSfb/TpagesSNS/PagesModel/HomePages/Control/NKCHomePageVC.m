//
//  NKCHomePageVC.m
//  TpagesSNS
//
//  Created by 冯鸿辉 on 15/10/26.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import "NKCHomePageVC.h"
#import "MDDefine.h"
#import "MDTool.h"
#import "NKCHomePageCell.h"
#import "DGCPostManager.h"
#import "DGCListInfo.h"
#import "DGCPostInfo.h"
#import "MJRefresh.h"
@interface NKCHomePageVC ()
<
UITableViewDataSource,
UITableViewDelegate,
DGCPostManagerDelegate
>
@property (weak, nonatomic) IBOutlet UIView *bgView;
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;
@property (weak, nonatomic) IBOutlet UIView *buttonsView;
@property (weak, nonatomic) IBOutlet UITableView *homePageTableView;
@property (weak, nonatomic) IBOutlet UIButton *btn1;
@property (weak, nonatomic) IBOutlet UIButton *btn2;
@property (weak, nonatomic) IBOutlet UIButton *btn3;
@property (weak, nonatomic) IBOutlet UIButton *btn4;
@property (weak, nonatomic) IBOutlet UIButton *btn5;
@property (weak, nonatomic) IBOutlet UIButton *btn6;

@property(nonatomic,strong)NSArray *dataArray;
@end

@implementation NKCHomePageVC

#pragma mark - < vc lifecycle> -
- (void)viewDidLoad
{
    [super viewDidLoad];

    [self customInitUI];
    [self customInitGetNetData];
}

-(void)customInitUI
{
    [self.homePageTableView setBackgroundColor:[UIColor clearColor]];
    [self.homePageTableView setDataSource:self];
    [self.homePageTableView setDelegate:self];
    [self.homePageTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [self.homePageTableView registerNib:[UINib nibWithNibName:@"NKCHomePageCell" bundle:nil] forCellReuseIdentifier:@"NKCHomePageCell"];
    
    
    [self.btn1 setBackgroundColor:[UIColor grayColor]];
    [self.btn1.layer setCornerRadius:38*0.5];
    [self.btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
}

-(void)customInitData
{
    _dataArray = [NSMutableArray array];
}

-(void)customInitGetNetData
{
    [[DGCPostManager share] getPostsBySince:1 before:1 per_page:1 site:1 host:1 type:1 user:1 userinfo:nil delegate:self];
}

#pragma mark - < callback >-
#pragma mark tableview
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NKCHomePageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NKCHomePageCell" forIndexPath:indexPath];
    DGCPostInfo *postInfo = [_dataArray objectAtIndex:indexPath.row];
    cell.postInfo = postInfo;
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DGCPostInfo *postInfo = [_dataArray objectAtIndex:indexPath.row];
    CGFloat cellHeight = [NKCHomePageCell heightForCellByContent:postInfo.detail];
    return cellHeight;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger row = indexPath.row;
    NSLog(@"cell row:%d",row);
}

#pragma mark net
-(void)DGCPosts:(DGCPostManager *)userServices isSuccess:(BOOL)isSuccess data:(DGCListInfo *)data errorCode:(DGCRequestErrorCode)code msg:(NSString *)msg userInfo:(NSDictionary *)userInfo
{
    if (isSuccess) {
        NSLog(@"请求成功");
        _dataArray = data.posts;
        [self.homePageTableView reloadData];
    }else{
        NSLog(@"请求失败：%d %@",code,msg);
    }
}


@end
