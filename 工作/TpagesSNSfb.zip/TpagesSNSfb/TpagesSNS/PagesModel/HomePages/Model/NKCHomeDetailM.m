//
//  NKCHomeDetailM.m
//  TpagesSNS
//
//  Created by NearKong on 15/10/25.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import "NKCHomeDetailM.h"

@implementation NKCHomeDetailM

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{ @"id" : @"id",
              @"site" : @"site",
              @"host" : @"host",
              @"type" : @"type",
              @"user" : @"user",
              @"emote" : @"emote",
              @"url" : @"url",
              @"content" : @"content",
              @"title" : @"title",
              @"num_likes" : @"num_likes",
              @"num_shares" : @"num_shares",
              @"num_comments" : @"num_comments",
              @"pictures" : @"pictures",
              @"update_time" : @"update_time"
              };
}

- (void)setNilValueForKey:(NSString *)key {
    [self setValue:@0 forKey:key];                                                        // For NSInteger/CGFloat/BOOL
}

@end
