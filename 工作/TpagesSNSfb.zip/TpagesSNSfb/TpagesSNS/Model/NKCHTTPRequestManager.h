//
//  NKCHTTPRequestManager.h
//  TpagesSNS
//
//  Created by NearKong on 15/10/22.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <libextobjc/EXTScope.h>
#import "UIKit+AFNetworking.h"
#import "AFNetworking.h"

#import "NKCHTTPRequestHeader.h"

@interface NKCHTTPRequestManager : NSObject

+ (NKCHTTPRequestManager *)shareInstance;
/**
 * 每次调用都会创建一个新的AFHTTPRequestOperationManager，由你的controller 来管理生命周期
 */
- (AFHTTPRequestOperationManager *)base_operationManager;
@end

