//
//  PersonalConfiguration.h
//  TpagesS
//
//  Created by KongNear on 15/9/15.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NKCPersonalConfiguration : NSObject

/** 当前设备类型：iPhone、iPad
 *
 */
@property (nonatomic, assign, readonly) UIUserInterfaceIdiom device;

/** 单例设计模式
 *      此类为APP状态，用户自定义设置。在程序启动时创建初始化，必须使用单例；
 *      PS:为免沉郁代码，init等方法不作屏蔽，但必须使用此方法制作单例
 */
+ (instancetype)sharePersonalConfiguration;


@end
