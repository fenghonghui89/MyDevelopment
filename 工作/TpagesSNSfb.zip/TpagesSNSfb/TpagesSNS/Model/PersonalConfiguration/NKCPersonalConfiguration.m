//
//  PersonalConfiguration.m
//  TpagesS
//
//  Created by KongNear on 15/9/15.
//  Copyright (c) 2015年 NearKong. All rights reserved.
//

#import "NKCPersonalConfiguration.h"


@implementation NKCPersonalConfiguration

#pragma mark - Class init
/** 单例设计模式
 *
 */
+ (instancetype)sharePersonalConfiguration{
    static NKCPersonalConfiguration *personalConfiguration = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        personalConfiguration = [[NKCPersonalConfiguration alloc] initPrivate];
    });
    return personalConfiguration;
}

/** 私有初始化方法
 *
 */
- (instancetype)initPrivate{
    self = [super init];
    if (self) {
        _device = [UIDevice currentDevice].userInterfaceIdiom;
    }
    return self;
}


@end
