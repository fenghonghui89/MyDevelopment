//
//  NKCHTTPRequestHeader.h
//  TpagesSNS
//
//  Created by NearKong on 15/10/23.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#ifndef NKCHTTPRequestHeader_h
#define NKCHTTPRequestHeader_h

#define base_IP @"https://120.26.213.94"

#pragma mark 帖子接口
#define post_posts @"/posts"

#pragma mark 查找接口
#define find_find @"/find"

#endif /* NKCHTTPRequestHeader_h */
