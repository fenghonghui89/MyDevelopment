//
//  NKCHTTPRequestManager.m
//  TpagesSNS
//
//  Created by NearKong on 15/10/22.
//  Copyright © 2015年 NearKong. All rights reserved.
//

#import "NKCHTTPRequestManager.h"
//#import <ALSystem.h>

@implementation NKCHTTPRequestManager
+ (NKCHTTPRequestManager *)shareInstance {
    static dispatch_once_t once;
    static id sharedInstance;
    dispatch_once(&once, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (AFHTTPRequestOperationManager *)base_operationManager {
    AFHTTPRequestOperationManager *_operationManagerZ = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:base_IP]];
    _operationManagerZ.responseSerializer = [AFJSONResponseSerializer serializer];                                                //这个是json解析
    _operationManagerZ.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
    _operationManagerZ.requestSerializer = [AFJSONRequestSerializer serializer];
    _operationManagerZ.requestSerializer.timeoutInterval = 20;
//    [_operationManagerZ.requestSerializer setValue:[ALNetwork currentIPAddress] forHTTPHeaderField:@"X-Real-IP"];
    
    //https
//    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
//    securityPolicy.allowInvalidCertificates = YES;
//    _operationManagerZ.securityPolicy = securityPolicy;

    _operationManagerZ.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    //解决“Error Domain=NSURLErrorDomain Code=-1012 "The operation couldn’t be completed.”的问题，AFNetworking 2.0默认在检查SSL证书的时候比较严格
    _operationManagerZ.securityPolicy.allowInvalidCertificates = true;
    
    return _operationManagerZ;
}
@end
