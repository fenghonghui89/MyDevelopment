SvImageInfo
===========

Obtain and manipulate image info with ImageIO framework
