//
//  SvImageInfoAppDelegate.h
//  SvImgeInfo
//
//  Created by  maple on 6/17/13.
//  Copyright (c) 2013 maple. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SvImageInfoViewController;

@interface SvImageInfoAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SvImageInfoViewController *viewController;

@end
