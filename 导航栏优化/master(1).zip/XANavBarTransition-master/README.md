smooth transition of navigation bar


![](https://github.com/XangAm/XANavBarTransition/raw/master/bardemo.gif)  



## Installation

- download XANavBarTransition demo
- import the header file：#import "XANavBarTransition.h"

```objc
#import XANavBarTransition.h
```
```objc
- (void)viewDidLoad {
    [super viewDidLoad];
    self.xa_navBarAlpha = 0;
}
```

## Article
- [iOS:记一次导航栏平滑过渡的实现](https://www.jianshu.com/p/859a1efd2bbf)



## Abount Lan
- weibo:[@关于岚](http://weibo.com/daxiec/)


