//
//  TRViewController.m
//  Day6GetImageFromSystem
//
//  Created by Tarena on 13-12-9.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()
@property (nonatomic, strong)UIView *v;
@property (nonatomic, strong)UIScrollView *sv;
@property (nonatomic, strong)NSMutableArray *images;
@property (nonatomic, strong)UIImageView *dragIV;
@end

@implementation TRViewController
- (IBAction)cllicked:(UIButton *)sender {
    self.images = [NSMutableArray array];
    
    UIImagePickerController *ipc = [[UIImagePickerController alloc]init];
    [ipc setSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
    ipc.delegate = self;
    [self presentViewController:ipc animated:YES completion:Nil];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    NSLog(@"%@",info);
    UIImage *image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
   
    UIImageView *iv = [[ UIImageView alloc]initWithFrame:CGRectMake(self.images.count *80, 0, 80, 80)];
    iv.userInteractionEnabled = YES;
   
    iv.image = image;
    [self.sv addSubview:iv];
    [self.sv setContentSize:CGSizeMake(80*self.images.count, 0)];
    //添加删除按钮
    UIButton *delBtn = [[UIButton alloc]initWithFrame:CGRectMake(60, 0, 20, 20)];
    delBtn.tag = self.images.count;
    [delBtn setBackgroundColor:[UIColor blackColor]];
    [delBtn setTitle:@"X" forState:UIControlStateNormal];
    [delBtn addTarget:self action:@selector(deleteImage:) forControlEvents:UIControlEventTouchUpInside];
    [iv addSubview:delBtn];
    
     [self.images addObject:image];
//    [self dismissViewControllerAnimated:YES completion:Nil];
}
// a d e
-(void)deleteImage:(UIButton*)btn{
//    [btn.superview removeFromSuperview];

    [self.images removeObjectAtIndex:btn.tag];
    
    
    for (UIView *iv in _sv.subviews) {
        [iv removeFromSuperview];
     
    }
    for (int i=0; i<self.images.count; i++) {
        UIImageView *iv = [[UIImageView alloc]initWithFrame:CGRectMake(i*80, 0, 80, 80)];
        iv.image = self.images[i];
        iv.userInteractionEnabled = YES;
        [_sv addSubview:iv];
        
        //添加删除按钮
        UIButton *delBtn = [[UIButton alloc]initWithFrame:CGRectMake(60, 0, 20, 20)];
        delBtn.tag = i;
        [delBtn setBackgroundColor:[UIColor blackColor]];
        [delBtn setTitle:@"X" forState:UIControlStateNormal];
        [delBtn addTarget:self action:@selector(deleteImage:) forControlEvents:UIControlEventTouchUpInside];
        [iv addSubview:delBtn];
    }
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
       [self dismissViewControllerAnimated:YES completion:Nil];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    UIScrollView *sv = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 320, 80)];
    [self.view addSubview:sv];
    
    for (int i=0; i<self.images.count; i++) {
        UIImageView *iv = [[UIImageView alloc]initWithFrame:CGRectMake(i*80, 0, 80, 80)];
        iv.image = [self.images objectAtIndex:i];
        iv.userInteractionEnabled = YES;
        [sv addSubview:iv];
        //添加拖动手势
        UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longAction:)];
        [iv addGestureRecognizer:lpgr];
    }
    [sv setContentSize:CGSizeMake(self.images.count*80, 0)];
    
    
}
-(void)longAction:(UILongPressGestureRecognizer*)lpgr{
    UIImageView *iv = (UIImageView*)lpgr.view;
    CGPoint p = [lpgr locationInView:self.view];
    
    switch ((int)lpgr.state) {
        case UIGestureRecognizerStateBegan:
        {
          self.dragIV = [[UIImageView alloc]initWithFrame:iv.frame];
            _dragIV.image = iv.image;
            [self.view addSubview:_dragIV];
        }
            break;
            
        case UIGestureRecognizerStateChanged:
        {
            if (self.dragIV) {
               self.dragIV.center = p;
            }
            
        }
            break;
        case UIGestureRecognizerStateEnded:
        {
            if (self.dragIV) {
                if (CGRectContainsPoint(_editView.frame, p)) {
                    
                    CGPoint center = self.dragIV.center;
                    //把相对于self.view的一点坐标转换到相对于ediView的坐标
                    CGPoint newCenter = [self.view convertPoint:center toView:self.editView];
                    
                    [_editView addSubview:self.dragIV];
                  self.dragIV.center = newCenter;
                    
                }else{
                    [_dragIV removeFromSuperview];
                    
                }
            }
        }
            break;
    }
    
    
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    NSLog(@"willShowViewController");
}
- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    self.v = [[ UIView alloc]initWithFrame:CGRectMake(0, 300, 320, 100)];
    _v.backgroundColor = [UIColor redColor];
    self.sv = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 20, 320, 80)];
//    [_sv setShowsHorizontalScrollIndicator:NO];
//    [_sv setShowsVerticalScrollIndicator:NO];
    
    [_sv setBackgroundColor:[UIColor blueColor]];
    [_v addSubview:_sv];
    [viewController.view addSubview:_v];
    //添加返回按钮
    UIButton *backBtn = [[UIButton alloc]initWithFrame:CGRectMake(220, 0, 100, 20)];
    [backBtn setTitle:@"Done" forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    [self.v addSubview:backBtn];
    NSLog(@"didShowViewController");
}
- (void)backAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)viewDidLoad
{
//    self.editView.clipsToBounds = YES;
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
