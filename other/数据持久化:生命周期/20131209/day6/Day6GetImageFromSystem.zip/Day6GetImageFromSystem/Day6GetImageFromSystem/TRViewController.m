//
//  TRViewController.m
//  Day6GetImageFromSystem
//
//  Created by Tarena on 13-12-9.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()
@property (nonatomic, strong)UIView *v;
@end

@implementation TRViewController
- (IBAction)cllicked:(UIButton *)sender {
    
    UIImagePickerController *ipc = [[UIImagePickerController alloc]init];
    [ipc setSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
//    ipc.allowsEditing = YES;
    ipc.delegate = self;
    [self presentViewController:ipc animated:YES completion:Nil];
    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    NSLog(@"%@",info);
    UIImage *image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    
    UIImageView *iv = [[ UIImageView alloc]initWithFrame:CGRectMake(0, 0, 100, 100)];
    iv.image = image;
    [self.v addSubview:iv];
    
    
//    [self dismissViewControllerAnimated:YES completion:Nil];
}



- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
       [self dismissViewControllerAnimated:YES completion:Nil];
}


- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    NSLog(@"willShowViewController");
}
- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    self.v = [[ UIView alloc]initWithFrame:CGRectMake(0, 300, 320, 100)];
    _v.backgroundColor = [UIColor redColor];
    [viewController.view addSubview:_v];
    
    NSLog(@"didShowViewController");
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
