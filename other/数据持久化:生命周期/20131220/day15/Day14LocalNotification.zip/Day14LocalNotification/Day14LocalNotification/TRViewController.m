//
//  TRViewController.m
//  Day14LocalNotification
//
//  Created by Tarena on 13-12-20.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()

@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    UILocalNotification *noti = [[UILocalNotification alloc]init];
    NSDate *date = [NSDate new];
    //设置发射时间为5秒之后
    noti.fireDate = [date dateByAddingTimeInterval:5];
    
    noti.alertBody = @"爷！好久没来玩儿啦";
    //图标上面显示的数
    noti.applicationIconBadgeNumber = 8;
    //传递参数
    noti.userInfo = @{@"name": @"zhangsan"};
    //设置重复时间
    [noti setRepeatInterval:NSCalendarUnitMinute];
    //把通知添加进日程
    [[UIApplication sharedApplication] scheduleLocalNotification:noti];
    
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
