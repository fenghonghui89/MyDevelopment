//
//  TRAd.h
//  TMusic
//
//  Created by Alex Zhao on 13-8-13.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRAd : NSObject

@property (copy, nonatomic) NSString * imageName;
@property (copy, nonatomic) NSString * linkAddress;

@end
