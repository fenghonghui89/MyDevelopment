//
//  TRTextFieldCell.h
//  TMusic
//
//  Created by Alex Zhao on 13-8-9.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRTextFieldCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UITextField *textField;

@end
