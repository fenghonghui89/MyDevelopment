//
//  TRPlayingListViewController.h
//  TMusic
//
//  Created by Alex Zhao on 13-8-21.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRPlayingViewController.h"
@interface TRPlayingListViewController : UITableViewController

@property (nonatomic, strong) NSArray * playingList;
@property (nonatomic,weak)TRPlayingViewController *delegate;
@end
