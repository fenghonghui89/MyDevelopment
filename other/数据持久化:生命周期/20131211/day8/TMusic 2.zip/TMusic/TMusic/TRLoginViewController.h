//
//  TRLoginViewController.h
//  TMusic
//
//  Created by Alex Zhao on 13-8-9.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRLoginViewController : UITableViewController

@property (strong, nonatomic) IBOutlet UIImageView *headerView;

@end
