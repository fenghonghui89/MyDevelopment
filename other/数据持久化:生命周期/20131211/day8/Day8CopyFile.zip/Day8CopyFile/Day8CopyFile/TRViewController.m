//
//  TRViewController.m
//  Day8CopyFile
//
//  Created by Tarena on 13-12-11.
//  Copyright (c) 2013年 Tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()
@property (nonatomic, strong)NSFileHandle *fileReader;
@property (nonatomic, strong)NSFileHandle *fileWrite;
@end

@implementation TRViewController


- (IBAction)clicked:(id)sender {
    
    //读取20k的数据
    NSData *subData = [_fileReader readDataOfLength:20*1024];
    //如果用同一个fileReader对象读取数据 fileReader会自动移动游标
    
    //如果用同一个fileWriter对象写数据 也会自动移动游标
    //把数据写到文件
    [_fileWrite writeData:subData];
    //将数据及时写出去
    [_fileWrite synchronizeFile];
//    //这种写data的方式会把原来的文件覆盖
//    [subData writeToFile:@"/Users/apple/Desktop/a.mp4" atomically:YES];
    
    
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    NSString *filePath = @"/Users/apple/Pictures/美女/杨幂/yangmi05.jpg";
    self.fileReader = [NSFileHandle fileHandleForReadingAtPath:filePath];
    
    
    NSString *newFilePath = @"/Users/apple/Desktop/b.jpg";
    //创建文件
    [[NSFileManager defaultManager] createFileAtPath:newFilePath contents:nil attributes:nil];
    
    //创建一个写数据的文件控制对象 需要注意 给的文件保存路径 一定要保证文件存在
    self.fileWrite = [NSFileHandle fileHandleForWritingAtPath:newFilePath];
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
